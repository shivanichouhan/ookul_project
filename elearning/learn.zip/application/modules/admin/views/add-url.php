<div class="forms">
	<h2 class="title1"><?= $title; ?></h2>
	<?= $this->session->flashdata('msg'); ?>
	<div class="row">		
		<div class="form-three widget-shadow">
			<form class="form-horizontal" method="post" action="<?php echo  base_url('admin/editurl'); ?>">
			    
			    
			    <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
                 <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">TV 1</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc'].'"'; ?> name="page_desc" placeholder="TV Url">
                 </div>
                </div>
              <div class="form-group">
                 <label for="inputEmail" class="col-lg-2 control-label">Radio Url</label>
                 <div class="col-lg-10">
                    <input type="text" class="form-control" <?php if(!empty($page)) echo 'value="'.$page[
            					    	'page_desc2'].'"'; ?> name="page_desc2" placeholder="TV Url">
                 </div>
              </div>	
				
			
				<div class="col-sm-offset-2">				
                <input type="submit" name="submit" value="Edit" class="btn btn-success">
				</div>
			</form>
		</div>
	</div>
</div>
	



