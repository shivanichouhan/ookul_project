<div class="row">
   <!--  <a href="<?php echo base_url('admin/donationhistory');?>"><div class="col-md-3 widget new-widget widget1">
        <div class="r3_counter_box">
            <i class="pull-left fa  fa-check-square user2 icon-rounded"></i>
            <div class="stats">
              <h5><strong><?php echo $payment?></strong></h5>
              <span>Total Member Payment</span>
            </div>
        </div>
    </div></a> -->

<!-- 	
<div class="col-md-3 widget new-widget widget1">
		<div class="r3_counter_box">
            <i class="pull-left fa fa-calendar-o dollar1 icon-rounded"></i>
            <div class="stats">
              <h5><strong><?php echo $event; ?></strong></h5>
              <span>Total Event</span>
            </div>
        </div>
	 </div> -->
	<a href="<?php echo base_url('admin/UserList');?>">
    <div class="col-md-3 widget new-widget">
		<div class="r3_counter_box">
            <i class="pull-left fa fa-users dollar2 icon-rounded"></i>
            <div class="stats">
              <h5><strong><?php echo $user?></strong></h5>
              <span>Total Members</span>
            </div>
        </div>
	 </div></a>
	  <!-- <a href="<?php echo base_url('admin/nonmemberdonationhistory');?>"><div class="col-md-4 widget new-widget widget1">
        <div class="r3_counter_box">
            <i class="pull-left fa  fa-check-square user2 icon-rounded"></i>
            <div class="stats">
              <h5><strong><?php echo $nonmenber_amount?></strong></h5>
              <span>Total none member payment</span>
            </div>
        </div>
    </div></a> -->
    </div>
	<div class="clearfix"> </div>
</div>


