<div class="prs_footer_main_section_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="prs_footer_cont1_wrapper prs_footer_cont1_wrapper_1">
						<a href="<?php echo base_url(); ?>">
						    <h4 style="color:#fff;">
						    Legends of Tomorrow
						    </h4>
						    </a>
						      
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="prs_footer_cont1_wrapper prs_footer_cont1_wrapper_2">
						
						<ul  style="padding-top:0px;">
							<li><i class="fa fa-circle"></i> &nbsp;&nbsp;<a href="#">About Us</a>
							</li>
							<li><i class="fa fa-circle"></i> &nbsp;&nbsp;<a href="#">Help & Support</a>
							</li>
							<li><i class="fa fa-circle"></i> &nbsp;&nbsp;<a href="#">FAQ</a>
							</li>

						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="prs_footer_cont1_wrapper prs_footer_cont1_wrapper_3">
					
						<ul style="padding-top:0px;">
							<li><i class="fa fa-circle"></i> &nbsp;&nbsp;<a href="e_contact.html">Contact Us</a>
							</li>
							<li><i class="fa fa-circle"></i> &nbsp;&nbsp;<a href="e_learningtermcondition.html">Term & Condition</a>
							</li>
							<li><i class="fa fa-circle"></i> &nbsp;&nbsp;<a href="e_learningpolicy.html">Privacy Policy</a>
							</li>
							<li><i class="fa fa-circle"></i> &nbsp;&nbsp;<a href="e_learningreturnpolicy.html">Return Policy</a>
							</li>
							
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="prs_footer_cont1_wrapper prs_footer_cont1_wrapper_4">
						<h2>App available on</h2>
						<p>Download App Legends of Tomorrow</p>
						<ul>
							<li>
								<a href="#">
									<img src="<?php echo base_url('assets/') ?>images/content/f1.jpg" alt="footer_img">
								</a>
							</li>
						<!-- 	<li>
								<a href="#">
									<img src="<?php echo base_url('assets/') ?>images/content/Paypal_visa_mastercard_amex_logo.png" alt="footer_img">
								</a>
							</li> -->
							
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="prs_bottom_footer_wrapper">	<a href="javascript:" id="return-to-top"><i class="flaticon-play-button"></i></a>
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-8 col-xs-12">
					<div class="prs_bottom_footer_cont_wrapper">
						<p> All rights reserved - Design by <a href="http://www.sveltose.in/">SVELTOSE TECHNOLOGIES</a>
						</p>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-4 col-xs-12">
					<div class="prs_footer_social_wrapper">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a>
							</li>
							<li><a href="#"><i class="fa fa-twitter"></i></a>
							</li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a>
							</li>
							<li><a href="#"><i class="fa fa-youtube-play"></i></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- prs footer Wrapper End -->
	<!-- st login wrapper Start -->
	<div class="modal fade st_pop_form_wrapper" id="myModal" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="st_pop_form_heading_wrapper float_left">
					<h3>Log in</h3>
				</div>
				<div id="errormsg" style="color:red"></div>
				<form id="loginid" method="post">
				<div class="st_profile_input float_left">
					<label>Email / Mobile Number</label>
					<input type="text" name="email" id="emailid">
				</div>

				<div class="st_profile__pass_input st_profile__pass_input_pop float_left">
					<input type="password" placeholder="Password" name="password" id="passid">
				</div>
				<div class="st_form_pop_fp float_left">
					<h3><a href="#" data-toggle="modal" data-target="#myModa2" target="_blank">Forgot Password?</a></h3>
				</div>

				<div class="st_form_pop_login_btn float_left">

				 <input  class="st_form_pop_or_btn float_left" style="    background:#ff4444;color:white;" type="submit" name="submit" value="LOGIN">
				</div>
			 </form>
				<div class="st_form_pop_or_btn float_left">
					<h4>or</h4>
				</div>
				<div class="st_form_pop_facebook_btn float_left">	<a href="#"> Connect with Facebook</a>
				</div>
				<div class="st_form_pop_gmail_btn float_left">	<a href="#"> Connect with Google</a>
				</div>
				<div class="st_form_pop_signin_btn float_left">
					<h4>Don’t have an account? <a href="#" data-toggle="modal" data-target="#myModa3" target="_blank">Sign Up</a></h4>
				<h5>I agree to the <a href="e_learningtermcondition.html">Terms & Conditions</a> & <a href="e_learningpolicy.html">Privacy Policy</a> & <a href="e_learningreturnpolicy.html">Return Policy</a></h5>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade st_pop_form_wrapper" id="myModa2" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="st_pop_form_heading_wrapper st_pop_form_heading_wrapper_fpass float_left">
					<h3>Forgot Password</h3>
					<p>We can help! All you need to do is enter your email ID and follow the instructions!</p>
				</div>
				<div class="st_profile_input float_left">
					<label>Email Address</label>
					<input type="text">
				</div>
				<div class="st_form_pop_fpass_btn float_left">	<a href="#">Verify</a>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade st_pop_form_wrapper" id="myModa3" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="st_pop_form_heading_wrapper float_left">

					<h3>Sign Up</h3>
				
				</div>
					<div id="signuperror" style="color:red"></div>
					<div id="successmsg" style="color:green"></div>
				<form id="sighup" method="post">
				<div class="st_profile_input float_left">
					<label>First Name</label>
					<input type="text" name="fname" id="fnameid" value="" required="required">
					<label>Last Name</label>
					<input type="text" name="lname" id="lnameid" value="" required="required">
					<label>Email</label>
					<input type="email" name="email" id="emailidd" required="required">
					<label>MObile Number</label>
					<input type="text" name="phone"  id="phoneid" value="" required="required">
					<label>state</label>
					<input type="text" name="state" id="stateid" value="" required="required">
					<label>City</label>
					<input type="text" name="city" id="cityid" value="" required="required">
					<label>District</label>
					<input type="text" name="district" id="districtid" value="" required="required">
					
				</div>
				<div class="st_profile__pass_input st_profile__pass_input_pop float_left">
					<input type="password" placeholder="Password" id="passwordid" name="password" required="required">
				</div>
				<div class="st_profile__pass_input st_profile__pass_input_pop float_left">
					<input type="password" placeholder=" Confirm Password" name="cpassword" id="txtConfirmPassword" required="required">
				</div>
				<div class="registrationFormAlert" style="color:green;" id="CheckPasswordMatch">			
				
					<div class="st_form_pop_login_btn float_left">

						<input  class="st_form_pop_or_btn float_left" style="    background:#ff4444;color:white;" type="submit" name="submit" value="Submit">
				</div>

			</form>

				
				<div class="st_form_pop_or_btn float_left">
					<h4>or</h4>
				</div>
				<div class="st_form_pop_facebook_btn float_left">	<a href="#"><i class="fab fa-facebook-f"></i> Connect with Facebook</a>
				</div>
				<div class="st_form_pop_gmail_btn float_left">	<a href="#"><i class="fab fa-google-plus-g"></i> Connect with Google</a>
				</div>
				<div class="st_form_pop_signin_btn st_form_pop_signin_btn_signup float_left">
					<h5>I agree to the <a href="e_learningtermcondition.html">Terms & Conditions</a> & <a href="e_learningpolicy.html">Privacy Policy</a> & <a href="e_learningreturnpolicy.html">Return Policy</a></h5>
				</div>
			</div>
		</div>
	</div>
	
	<!-- st login wrapper End -->
	
	
	<!--main js file start-->
	<script src="<?php echo base_url('assets/') ?>js/jquery_min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/modernizr.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/bootstrap.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/owl.carousel.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/jquery.dlmenu.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/jquery.sticky.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/jquery.nice-select.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/jquery.magnific-popup.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/jquery.bxslider.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/venobox.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/smothscroll_part1.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/smothscroll_part2.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/jquery.themepunch.revolution.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/jquery.themepunch.tools.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.addon.snow.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.actions.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.carousel.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.kenburn.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.layeranimation.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.migration.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.navigation.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.parallax.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.slideanims.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/plugin/rs_slider/revolution.extension.video.min.js"></script>
	<script src="<?php echo base_url('assets/') ?>js/custom.js"></script>
	<!--main js file end-->
</body>
<script type="text/javascript">

$( document ).ready(function()
{

	function checkPasswordMatch() {
        var password = $("#passwordid").val();
        var confirmPassword = $("#txtConfirmPassword").val();
        if (password != confirmPassword)
            $("#CheckPasswordMatch").html("Passwords does not match!");
        else
            $("#CheckPasswordMatch").html("Passwords match.");
    }

    $("#txtConfirmPassword").keyup(checkPasswordMatch);






	$("#sighup").submit(function(e){
		 e.preventDefault();

		  var email	=  $('#emailidd').val();
		 var fname	=  $('#fnameid').val();
		 var lname	=  $('#lnameid').val();
		 var phone	=  $('#phoneid').val();
		 var password	=  $('#passwordid').val();
		 var state	=  $('#stateid').val();
		 var city	=  $('#cityid').val();
		 var district = $('#districtid').val();
	      $.ajax({
	         type: "POST",
	         url: "<?php echo base_url('home/signup') ?>", 
	         data: {email:email,password:password,fname:fname,lname:lname,phone:phone,state:state,city:city,district:district},
	         dataType: "json",  
	         cache:false,
	         success: 
	              function(data){	              	
	                 console.log(data.code);
	                 if(data.code ==1)
	                 $("#successmsg").html("Successfully signup");
	                else
	             	  $("#signuperror").html(data.msg);
	                console.log(data); 
	              }
	     
	 });
	});

$("#loginid").submit(function(e)
{

var email	=  $('#emailid').val();
var pass	=  $('#passid').val();
	 e.preventDefault();
      $.ajax({
         type: "POST",
         url: "<?php echo base_url('home/login') ?>", 
         data: {email:email,pass:pass  },  
         cache:false,
         success: 
              function(data)
              {
              	if(data==1)
              	{

              	  window.location.href = "<?php echo base_url('home/profile'); ?>";
              	}else{

              		$("#errormsg").html("email and password is wrong");
              	}
               
               }

    
 });
});

});
</script>


<!-- Mirrored from www.webstrot.com/html/moviepro/html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 18 Sep 2020 06:47:07 GMT -->
</html>