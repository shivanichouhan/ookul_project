<?php
include"../include/database.php";
$obj=new database();
$web_info=$obj->fetchByIdTable("website_details");

  $user_id=$_GET['user_id'];

  $product_id=$_GET['id'];

  $web_name=$web_info['web_name'];
 
 $facebook=$web_info['facebook'];
 $twitter=$web_info['twitter'];
 $google=$web_info['google'];
 
  $mail=$web_info['email'];
 
   $phone=$web_info['phone'];


$user=$obj->fetchById($user_id,"user_register","id");
 $fname=$user['fname'];

 $email=$user['email'];
$product=$obj->fetchById($product_id,"enagic_pro","id");
 $title=$product['title'];
 $category=$product['category'];
 $discription=$product['discription'];
 $price=$product['price'];

$cat=$obj->fetchById($category,"category_id","id");
$catag=$cat['category'];
         
$date=date("Y-m-d");

$rs=$obj->send_mesages($user_id,$product_id);

if($rs)
{
	$url='http://localhost/water_new';
	
	$to=$email;
	
	$msg='
<html>
<head>
<title>Send Message</title>
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body style="background-color:lightgray;">
<section>
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-8">
<div class="head" style="background-color:white; height:40px;">
<p style="display:inline; margin-left: 26pc"><b>Email:'.$mail.'</b>
<a href="mailto:sheetaldevelopersveltosest0027@gmail.com" target="_blank">sheetaldevelopersveltosest0027<wbr>@gmail.com</a></p>
<p style="display:inline; margin-left:38pc"><b>Phone:</b>'.$phone.'</p>


</div>

<div class="head2" style="background-color:#F49CAB; height:110px;">
<img src="img/sveltose.png"style="
    margin-left: 18pc;
    margin-top: 10px;">
</div>
</div></div>
</div>
</section>

<section>
<div class="container">
<div class="row">
<div class="col-md-2">

</div>
<div class="col-md-8"> 
<div class="head3" style="background-color:white; height:550px; position:static;" >
<div class="email">
<p style="font-size: 36px;
    text-align: center;
    
    padding-top: 30px;">Send Product</p>
	
	
	<div class="not" style="background-color: #80808045;
    margin-left: 25px;
    margin-right: 25px;
    border: 1px solid #80808045;">
	<h4  style="margin-left:60px; margin-top:10px;">Name:'.$fname.'</h4>
	<h4  style="margin-left:60px; margin-top:10px;">Email:'.$email.'</h4>
	
	<h4  style="margin-left:60px ; margin-top:10px;">Category:'.$catag.'</h4>
	<h4  style="margin-left:60px ; margin-top:10px;">Title:'.$title.'</h4>
	<h4  style="margin-left:60px ; margin-top:10px;">Discriptionech:'.$discription.'</h4>
	<h4 style="margin-left:60px; margin-top:10px;">Price:'.$price.'</h4>
	<h4 style="margin-left:60px; margin-top:10px;">Date:'.$date.'</h4>
	 <P style="margin-left:21px; padding:18px;">Send product Successfully.</P>
  
 	</div>
	</div>
	</div>
</div>
</div>
</div>
<div class="col-md-2">
</div>
</div>
</div>
</section>
<section>
<div class="container">
<div class="row" style="margin-top:10px;">
<div class="col-md-2">
</div>
<div class="col-md-8">
<div class="head5" style="height:78px; background-color:whitesmoke;">
<p style="padding:15px;font-size:17px;color:black;">Phasellus dictum sapien a neque luctus cursus. Pellentesque sem dolor, fringilla et pharetra vitae.
<a href="#" style="margin-left:12px;">Click it! >></a></p>

</div>
</div>
<div class="col-md-2">
</div>
</div>
</div>
</section>
<section>
<div class="container">
<div class="row" style="margin-top:10px;">
<div class="col-md-2">
</div>
<div class="col-md-8">
<div class="head6"style="background-color:#b3b9bd;height:150px;" >
<div class="col-md-6" >
<div class="social">
<h5 class="con"style="font-size:23px;color:white;">Connect with Us:</h5>
<p class="fac"><a href="'.$facebook.'" class="soc-btn fb" style="padding: 3px 7px;
    font-size: 12px;
    margin-bottom: 10px;
    text-decoration: none;
    color: #FFF;
    font-weight: bold;
    display: block;
    text-align: center; background-color:#3B5998!important;">Facebook</a> 
<a href="'.$twitter.'" class="soc-btn tw" style="padding: 3px 7px;
    font-size: 12px;
    margin-bottom: 10px;
    text-decoration: none;
    color: #FFF;
    font-weight: bold;
    display: block;
    text-align: center; background-color:#2BA6CB">Twitter</a>
<a href="'.$google.'" class="soc-btn gp" style="padding: 3px 7px;
    font-size: 12px;
    margin-bottom: 10px;
    text-decoration: none;
    color: #FFF;
    font-weight: bold;
    display: block;
    text-align: center; background-color:#DB4A39!important;">Google+</a>
</p>
</div>

</div>
<div class="col-md-6" >
<div class="contact">
<h5 class=""style="font-size: 23px;
    color: white;">Contact Info:</h5>
<p style="color:white;">Phone: <strong>'.$phone.'</strong><br>
Email: <strong><a href="emailto:hseldon@trantor.com">'.$mail.'</a></strong></p>
</div>
</div>
</div>
</div>
<div class="col-md-2">
</div>
</div>
</div>
</section>
<section>
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-8" style="">
<p class="copyright-footer" style="text-align:center; margin-top:20px;color:black;">
                        © 2018 All rights reserved. | '.$web_name.' <a href="https://sveltosetech.com" target="_blank"></a> </p>
</div>
<div class="col-md-2">
</div>
</div>
</div>
</section>
</body>
</html>';

 $subject = "KengenWater"; 
      $from = "noreply@KengenWater.com";
	$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
	$headers .="From:".$from;
	$a=mail($email,$subject,$msg,$headers);

	 $_SESSION['msg']="Send  successfully";
	header("location:enagi_store.php");
}
else
{ 
 $_SESSION['msg']="Failed...";
	header("location:enagi_store.php");
}
?>
