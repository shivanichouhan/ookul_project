<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$level=$_POST['level'];
$price=$_POST['price'];

$rs=$obj->update_level($level,$price,$id);
if($rs)
{
	$_SESSION['msg']=" Update Success Full";
	header("location:royal_level.php");
}
else
{
	$_SESSION['msg']=" Not update";
	header("location:royal_level.php");
	
}
?>