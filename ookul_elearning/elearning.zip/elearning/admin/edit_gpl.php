<?php include"header.php";
include"menu.php"; 
$con=$obj->fetchById($_GET['id'],"goverment_popular_video","id");
?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Popular Video</h1>
                                <small>Edit Papular Video</small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="govermnt_popular_video.php">Popular Video List</a></li>
                                    <li class="active">Edit Popular Video</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
							<form data-toggle="validator" action="edit_g_pap_video_sub.php" method="post" enctype="multipart/form-data">
                       <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" >

                                <div class="panel panel-bd lobidrag">
									
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit popular Video </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
											
                                            
											
									<div class="form-group">
									<label for="inputName" class="control-label">Heading</label>
										<input type="text" name="heading" class="form-control"  value="<?php echo $con['heading'];?>">
									</div>	
									<div class="form-group">
									<label for="inputName" class="control-label">Thumbnail<p  style="background: #da0f3e;  color: #e8dede; ">(200*200)</p></label>
									
                                                <input type="file" class="form-control" id="exampleInputEmail1" name="thumbnai" placeholder="image">
												<input type="hidden" class="form-control" name="limg" value="<?php  $con['thumbnai'];?>">
										<!--<input type="file" name="thumbnai" class="form-control"  value="<?php echo $con['thumbnai'];?>">-->
									</div>										
									<div class="form-group">
									<label for="inputName" class="control-label">Video <p style="    background: #da0f3e;
    color: #e8dede;">(All mobile divice support mp4 format  and  format some mobile device mkv format)</p></label>
    
                                         <input type="file" class="form-control" id="exampleInputEmail1" name="video" placeholder="image">
												<input type="hidden" class="form-control" name="limg1" value="<?php  $con['video'];?>">
												
										<!--<input type="file" name="video" class="form-control"  value="<?php echo $con['video'];?>" >-->
									</div>
				
										
									<!--<div class="form-group">
										<label for="inputName" class="control-label">Contant</label>
										<textarea id="summernote" name="contant"></textarea>
										</div>-->
										<div class="form-group">
										<button type="submit" class="btn btn-primary">Submit</button>
										</div>
                                    </div>
                                </div>
								</form>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
       <?php include"footer.php"; ?>
	   <!-- jQuery -->
        