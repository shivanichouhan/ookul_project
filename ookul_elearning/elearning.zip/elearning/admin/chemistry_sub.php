<?php
include"../include/database.php";
$obj=new database();


		$filename=$_FILES["file"]["tmp_name"];		


		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
	        while (($data = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
                {  
                $aa=$obj->insert_chemistry($data[0],$data[1],$data[2],$data[3],$data[4],$data[5],$data[6],$data[7]);
                
                }
	         }
	          echo ("<script LANGUAGE='JavaScript'>
          window.alert('Uploaded');
          window.location.href='chemistry';
       </script>");
		 }
		 else {
		     
		     	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Upload');
          window.location.href='chemistry';
       </script>");

		 }

