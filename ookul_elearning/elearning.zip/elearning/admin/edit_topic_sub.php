<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

 $id=$_POST['id'];
 $class=$_POST['class'];
 $subject=$_POST['subject'];
 $chapter=$_POST['chapter'];
 $topic=$_POST['topic'];
 $contant=$_POST['contant'];


$path2="upload/";

 if($_FILES['topic_pic']['name']=="") { $topic_pic=$_POST['limg2']; } else { $topic_pic=$_FILES['topic_pic']['name']; move_uploaded_file($_FILES['topic_pic']['tmp_name'],$path2.$topic_pic); }

$path="upload/";

 if($_FILES['doucment']['name']=="") { $img=$_POST['limg']; } else { $img=$_FILES['doucment']['name']; move_uploaded_file($_FILES['doucment']['tmp_name'],$path.$img); }
 
 

$rs=$obj->update_topic($class,$subject,$chapter,$topic,$topic_pic,$img,$contant,$id);

if($rs)
{
echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update success');
          window.location.href='topic_list';
       </script>");
}
else
{
echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update');
          window.location.href='topic_list';
       </script>");



}


?>