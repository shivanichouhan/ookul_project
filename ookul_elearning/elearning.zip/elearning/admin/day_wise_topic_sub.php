<?php
include"../include/database.php";
$obj=new database();

$days=$_POST['days'];
$subject=$_POST['subject'];
$topic=$_POST['topic'];

$mainsubject=0;

$path1="gov_upload/";
$img=$_FILES['images']['name']; move_uploaded_file($_FILES['images']['tmp_name'],$path1.$img);



$frees_status=$_POST['frees_status'];

$rs=$obj->insert_subjectwisetopic($days,$subject,$topic,$mainsubject,$img,$frees_status);

if($rs)
{
    	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Inserted');
          window.location.href='day_wise_topic';
       </script>");
}
else
{
    	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Inserted');
          window.location.href='day_wise_topic';
       </script>");
}
?>