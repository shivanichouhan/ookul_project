<?php
include"../include/database.php";
$obj=new database();


$potal_code=$_POST['potal_code'];
$delivery_charges=$_POST['delivery_charges'];

$io=$obj->fetchById($potal_code,"delivery_charges","potal_code");

if($io['potal_code']==$potal_code)
{
	echo"";
	$_SESSION['msg']="Postal Code Already Exist";
	header("location:postal_charge.php");
}
else
{
$rs=$obj->insertdelivery_charges($potal_code,$delivery_charges);
if($rs)
{
//	$_SESSION['msg']="Insert Success Full";
//	header("location:postal_charge.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='postal_charge';
       </script>");
}
else
{
//	$_SESSION['msg']="Not Insert";
	//header("location:postal_charge.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='postal_charge';
       </script>");
}
}
?>