<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");
;
$class=$_POST['class'];
$contant=$_POST['contant'];

$path="upload/";
$img=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path.$img);

$rs=$obj->insertcontant($class,$contant,$img);
if($rs)
{
	
	$_SESSION['msg']=" Insert  User Success Full";
	header("location:add_contant.php");
}
else
{
	$_SESSION['msg']="Insert user  Not Success Full";
	header("location:add_contant.php");
}
?>