<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
 $name=$_POST['name'];
$level_id=$_POST['level_id'];
$start_date=$_POST['start_date'];
$end_date=$_POST['end_date'];
$t_student=$_POST['t_student'];
$user_name=$_POST['user_name'];
//$user_name=implode(",",$user_name1);

$rs=$obj->update_royality($name,$level_id,$start_date,$end_date,$t_student,$user_name,$id);
if($rs)
{
	$_SESSION['msg']=" update Success Full";
	header("location:royality_list.php");
}
else
{
	$_SESSION['msg']=" Not update";
	header("location:royality_list.php");
	
}
?>