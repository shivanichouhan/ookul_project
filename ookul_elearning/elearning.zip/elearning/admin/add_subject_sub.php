<?php
include"../include/database.php";
$obj=new database();

$class=$_POST['class'];
$subject=$_POST['subject'];


$path="upload/";

$img=$_FILES['icon1']['name']; move_uploaded_file($_FILES['icon1']['tmp_name'],$path.$img);

$img1=$_FILES['images']['name']; move_uploaded_file($_FILES['images']['tmp_name'],$path.$img1);


$rs=$obj->insertsubject($class,$subject,$img,$img1);

if($rs)
{
//	$_SESSION['msg']=" Insert Success Full";
//	header("location:add_subject.php");
	
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert Success Full');
          window.location.href='add_subject.php';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Insert";
//	header("location:add_subject.php");

	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Success Full');
          window.location.href='add_subject.php';
       </script>");
}
?>