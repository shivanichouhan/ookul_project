<?php
include"../include/database.php";
include"../include/session.php";

$obj=new database();

       
          @$id=$_POST['id'];
     
     
   
    @$message=$_POST['message'];

  

    

 $rs=$obj->feedback2_update($message,$id);
if($rs)
  
{ 
	$_SESSION['msg']=" msg send";
  header("location:feedback_reply.php");
// 		echo ("<script LANGUAGE='JavaScript'>
//           window.alert('');
//           window.location.href='feedback_reply';
//       </script>");
}
else
{
	$_SESSION['msg']=" Not send";
	header("location:feedback_reply.php");
// 		echo ("<script LANGUAGE='JavaScript'>
//           window.alert('');
//           window.location.href='feedback_reply';
//       </script>");
}
?>