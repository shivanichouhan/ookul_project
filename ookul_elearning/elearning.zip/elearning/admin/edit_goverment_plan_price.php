<?php include"header.php";
include"menu.php"; 
$rs007=$obj->fetchById($_GET['id'],"goverment_plan","id");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
           <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                              <i class="fa fa-user" aria-hidden="true"></i>
                            </div>
                            <div class="header-title">
                                <h1>Government Plan Pricing </h1>
                                <small>Edit Government Plan Pricing <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="goverment_plan_price_list">Government Plan Pricing List</a></li>
                                    <li class="active">Government Plan Pricing</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
						<form data-toggle="validator" action="edit_gove_plan_sub" method="post" enctype="multipart/form-data">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Government Plan Pricing</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                    <input type="hidden" name="id" value="<?php echo $rs007['id']?>">    
										<div class="form-group">
                                                <label for="inputName" class="control-label">Full Amount</label>
                                                <input value="<?php echo $rs007['price']?>" type="number" class="form-control" id="inputName" name="famount" placeholder="Full Amount" required>
                                        </div>
										<div class="form-group">
                                                <label for="inputName" class="control-label">Full Amount GST</label>
                                                <input value="<?php echo $rs007['gst']?>" type="number" class="form-control" id="inputName" name="fagst" placeholder="Full Amount GST" required>
                                        </div>
										<div class="form-group">
                                                <label for="inputName" class="control-label">Partial Amount</label>
                                                <input value="<?php echo $rs007['partial_payment']?>" type="number" class="form-control" id="inputName" name="pamount" placeholder="Partial Amount" required>
                                        </div>
										<div class="form-group">
                                                <label for="inputName" class="control-label">Partial GST</label>
                                                <input value="<?php echo $rs007['partial_gst']?>" type="number" class="form-control" id="inputName" name="pgst" placeholder="Partial GST" required>
                                        </div>
										
									
									
											
<div class="form-group">
<button type="submit" class="btn btn-primary" style="    background: -webkit-linear-gradient(left, #ff771c 0%, #ea00ca 50%,#9d09e9 90%);
    border: 1px solid transparent;
    font-weight: 700;">Edit</button>
                                            </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
						</form>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div>



       <?php include"footer.php"; ?>