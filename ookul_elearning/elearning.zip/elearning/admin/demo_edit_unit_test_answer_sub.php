<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$class_id=$_POST['class_id'];

$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
$answer=$_POST['answer'];



$rs=$obj->updateanswer_demo($class_id,$subject,$chapter,$answer,$id);
if($rs)
{
	//$_SESSION['msg']=" Update Success Full";
	//header("location:demo_unit_answer_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_unit_answer_list';
       </script>");
}
else
{
	//$_SESSION['msg']=" Not Update";
	//header("location:demo_unit_answer_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_unit_answer_list';
       </script>");
}
?>