<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");
 $id=$_POST['id'];
 $transaction_id=$_POST['transaction_id'];

$upda=$obj->update_with($id,$transaction_id);

if($upda)
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='withdrawal_list';
       </script>");
//	$_SESSION['msg']=" Insert   Success Full";
	//header("location:withdrawal_list.php");
}
else
{
echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='withdrawal_list';
       </script>");
}









?>