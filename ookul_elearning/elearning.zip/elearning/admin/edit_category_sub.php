<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$category=$_POST['category'];


$rs=$obj->updatecategory($category,$id);
if($rs)
{
	$_SESSION['msg']=" Insert Success Full";
	header("location:category.php");
}
else
{
	$_SESSION['msg']=" Not Insert";
	header("location:category.php");
}
?>