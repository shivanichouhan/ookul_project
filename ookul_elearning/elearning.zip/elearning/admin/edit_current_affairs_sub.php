<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");


$id=$_POST['id'];
$months=$_POST['months'];
$title=$_POST['title'];
$description=$_POST['description'];

$path2="gov_upload/";
$thumbnail=$_FILES['thumbnail']['name']; move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path2.$thumbnail);


$path1="gov_upload/";
$video=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path1.$video);



$rs=$obj->update_current_affairs($months,$title,$description,$thumbnail,$video,$id);

if($rs)
{
    
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert success');
          window.location.href='current_affairs.php';
       </script>");
}
else
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not insert');
          window.location.href='current_affairs.php';
       </script>");
}



?>