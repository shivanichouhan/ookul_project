<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$days=$_POST['days'];
$subject=$_POST['subject'];

$uu=$obj->fetchByIdByStatus($days,"assign_subject","days","subject",$subject);
if($uu)
{
    $_SESSION["mag"]="Subject All Rady Exit this day";
    header("location:day_wise_subject.php");
}
else
{ 
$rs=$obj->Update_subject_daywise0000($days,$subject,$id);
if($rs)
{
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update Success');
          window.location.href='day_wise_subject';
       </script>");
	
}
else
{
	
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update Success');
          window.location.href='day_wise_subject';
       </script>");
}
}
?>