<?php include"header.php";
include"menu.php"; 
$b=explode('/',$a);
 $_GET['id']=$b['5']; 
?>            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Relationship Manager  </h1>
                                <small>Add Relationship Manager <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="referal_angent_list">Relationship Manager  List</a></li>
                                    <li class="active">Relationship Manager </li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                        <form data-toggle="validator" action="<?php echo $base1; ?>referal_agent_sub" method="post" enctype="multipart/form-data">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Relationship Manager </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                    <div class="form-group">
                                                <label for="inputName" class="control-label">Username</label>
                                                <input type="text" class="form-control" id="inputName" name="username" placeholder="name"  required>
                                        </div>
                                        <div class="form-group">
                                                <label for="inputName" class="control-label">Email</label>
                                                <input type="email" class="form-control" id="inputName" name="email" placeholder="email" required>
                                        </div>
                                        <div class="form-group">
                                                <label for="inputName" class="control-label">Password</label>
                                                <input type="password" class="form-control" id="inputName" name="password" placeholder="password" required>
                                        </div>
                                        <div class="form-group">
                                                <label for="inputName" class="control-label">Mobile Number</label>
                                                <input type="text" class="form-control" id="inputName" name="mobile" placeholder="Mobile" required>
                                        </div>
                                                                                <div class="form-group">
                                                <label for="inputName" class="control-label">Amount</label>
                                                <input type="text" class="form-control" id="inputName" name="amount" placeholder="amount" required>
                                        </div>
                                            <div class="form-group">
                                                <label for="inputName" class="control-label">Address</label>
                                                
                                                <textarea class="form-control" id="inputName" name="address" required></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputName" class="control-label">Note</label>

                                                <textarea id="summernote1" name="note" required></textarea>
                                            </div>
                                        <div class="form-group">
                                                <label for="exampleSelect1">Executive Supervisor</label>
                                                
                                                <select class="form-control" id="exampleSelect1" name="executive_id[]"  onChange="clas(this.value);" multiple>
                                                 <option value="">--Executive Supervisor--</option>
                                                <?php
                                                    $table='agent';
                                                    $rs=$obj->fetchAllDetailByStatus0004($table);
                                                    if($rs)
                                                    {   $i=0;
                                                        while($row=mysqli_fetch_assoc($rs))
                                                        {   $i++;
																
                                                            ?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name'];  ?></option>
                                                    <?php } 
                                                    }
                                                    ?>
                                                </select>
                                                        
                                            </div>
                                 <!--   <div class="form-group">
                                                <label for="exampleSelect1">Multiple Block</label>
                                                
                                                <select class="form-control" id="exampleSelect1" name="block[]"  onChange="clas(this.value);" multiple>
                                                 <option value="">--Block--</option>
                                                <?php
                                                    $table='block';
                                                    $rs=$obj->fetchAllDetailByStatus($table);
                                                    if($rs)
                                                    {   $i=0;
                                                        while($row=mysqli_fetch_assoc($rs))
                                                        {   $i++;
      
                                                            ?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['block'];  ?></option>
                                                    <?php } 
                                                    }
                                                    ?>
                                                </select>
                                                        
                                            </div>-->
											 <div class="form-group">
                                                <label for="exampleInputFile">Profile</label>
                                                <input type="file" name="image" id="exampleInputFile" aria-describedby="fileHelp">
                                               
                                            </div>
                                        <div class="form-group">
                                                <label for="exampleInputFile">Upload document</label>
                                                <input type="file" name="document" id="exampleInputFile" aria-describedby="fileHelp">
                                               
                                            </div>
                                            <div class="form-group">
                                            <p style="padding: 20px; background-color: #f44336; color: white;">Bank Account Details</p>
                                            </div>
                                            	<div class="form-group">
                                                <label for="inputName" class="control-label">Account Holder Name</label>
                                                <input type="text" class="form-control" id="inputName" name="account_holder_name" placeholder="Account Holder Name" required>
                                        </div>
                                        	<div class="form-group">
                                                <label for="inputName" class="control-label">Account Number</label>
                                                <input type="text" class="form-control" id="inputName" name="account_number" placeholder="Account Number" required>
                                        </div>
                                        	<div class="form-group">
                                                <label for="inputName" class="control-label">IFC Code</label>
                                                <input type="text" class="form-control" id="inputName" name="ifc_code" placeholder="IFC Code" required>
                                        </div>
                                        <div class="form-group">
                                                <label for="inputName" class="control-label">Branch Name</label>
                                                <input type="text" class="form-control" id="inputName" name="branch_name" placeholder="Branch Name" required>
                                        </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
                    
<script>
 function blok(b){
                 alert(b);
                 $("#block").load("blockAjax.php?id="+b);
                  }
</script>               
<script>
 function aap(a){
                 alert(a);
                 $("#city").load("agentAjax.php?id="+a);
                  }
</script>
                   <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>
         <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote1').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>

       <?php include"footer.php"; ?>