<?php
include"../include/database.php";
 include"../include/session.php";
$obj=new database();
session_start();
 $login = date("d-m-Y h:i:sa");
$rs=$obj->updateStatus(@$_SESSION['admin_id'],'admin','last_login',$login,"id");
unset($_SESSION['admin_id']);
//session_destroy();
//header("location:index.php");


	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Logout Successfull');
          window.location.href='index';
       </script>");
?>