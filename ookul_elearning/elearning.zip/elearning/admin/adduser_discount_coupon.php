<?php include"header.php";

include"menu.php"; ?>
<?php $con=$obj->fetchById($_GET['id'],"discount_code","id"); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

 <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Add User</h1>
                                <small>Add User</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="discount_coupon_list.php">Discount Coupon List</a></li>
                                    <li class="active">Add User</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->

                        <div class="row">
                            <div class="col-sm-12">
							<form data-toggle="validator" action="add_user_dsicount_sub.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" >
									
                                <div class="panel panel-bd lobidrag">
									
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add User  </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
											
                                            
											
										<div class="form-group">
											  <label for="exampleInputEmail1">User</label>

<select class="form-control select2" data-placeholder="Choose a city..."  multiple name="user[]"  required>

<?php
$row=$obj->fetchAllDetail("user_register_goverment");
 if($row){
 while($rs=mysqli_fetch_assoc($row)){?>
<option selected="selected"   value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?></option>
   <?php }}?>
												</select>
							  
											</div>	
									
										<div class="form-group">
										<button type="submit" class="btn btn-primary">Submit</button>
										</div>
                                    </div>
                                </div>
								</form>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
       <?php include"footer.php"; ?>
	   <!-- jQuery -->
        