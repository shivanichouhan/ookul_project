<?php
include"../include/database.php";
$obj=new database();

$class_id=$_POST['class_id'];

$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
$question=$_POST['question'];
$answer=$_POST['answer'];


$rs=$obj->demo_insertanswer($class_id,$subject,$chapter,$question,$answer);
if($rs)
{
	$_SESSION['msg']=" Insert Success Full";
	header("location:demo_question_answer_list.php");
}
else
{
	$_SESSION['msg']=" Not Insert";
	header("location:demo_question_answer_list.php");
}
?>