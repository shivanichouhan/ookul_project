<?php 
include_once("../include/database.php");
$obj= new database();
?>
<html>
<head><title></title></head>
<body>
<form data-toggle="validator" action="mobile_fetch.php" method="post">
<table>
<tr>
<td>Mobile</td><td>
<input type="text" name="mobile">
</td>
</tr>

<tr>
<td></td><td><input type="submit" value="submit" ></td>
</tr>

</table>
</form>

</body>
</html>