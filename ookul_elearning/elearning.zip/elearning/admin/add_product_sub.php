<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");
$category=$_POST['category'];
 $product=$_POST['product'];
$price=$_POST['price'];
 $discount_type=$_POST['discount_type'];
$discount_amount=$_POST['discount_amount'];
$contant=$_POST['contant'];

$path="upload/";
$img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path.$img);

$rs=$obj->insertproduct($category,$product,$img,$price,$discount_type,$discount_amount,$contant);

if($rs)
{
	
//	$_SESSION['msg']=" Insert  User Success Full";
//	header("location:add_shopping_product.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='add_shopping_product';
       </script>");
}
else
{
//	$_SESSION['msg']="Insert user  Not Success Full";
	//header("location:add_shopping_product.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='add_shopping_product';
       </script>");
}


?>
