<?php include"header.php";
include"menu.php"; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Partent Popular videos</h1>
                                <small>Add Popular videos</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="ppl.php">
Partent Popular Videos List</a></li>
                                    <li class="active">Add Partent Popular Video</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
							<form data-toggle="validator" action="parent_papular_video_sub.php" method="post" enctype="multipart/form-data">
                        
                                <div class="panel panel-bd lobidrag">
									
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Popular Video </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
											
                                            
											
									<div class="form-group">
									<label for="inputName" class="control-label">Heading</label>
										<input type="text" name="heading" class="form-control">
									</div>		
									<div class="form-group">
									<label for="inputName" class="control-label">Thumbnail</label>
										<input type="file" name="thumbnail" class="form-control">
									</div>
									<div class="form-group">
									<label for="inputName" class="control-label">Video</label>
										<input type="file" name="video" class="form-control">
									</div>
									
									
										<div class="form-group">
										<button type="submit" class="btn btn-primary">Add popular</button>
										</div>
                                    </div>
                                </div>
								</form>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
       <?php include"footer.php"; ?>
	   <!-- jQuery -->
        