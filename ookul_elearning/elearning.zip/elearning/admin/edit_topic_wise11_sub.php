<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

$id=$_POST['id'];
$class=$_POST['class'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
$topic=$_POST['topic'];
$video_name=$_POST['video_name'];

$path1="upload/";
 if($_FILES['thaminal1']['name']=="") { $thaminal1=$_POST['limg']; } else { $thaminal1=$_FILES['thaminal1']['name']; move_uploaded_file($_FILES['thaminal1']['tmp_name'],$path1.$thaminal1); }

$path11="upload/";
//$vedio1=$_FILES['vedio1']['name']; move_uploaded_file($_FILES['vedio1']['tmp_name'],$path11.$vedio1);
 if($_FILES['vedio1']['name']=="") { $vedio1=$_POST['limg11']; } else { $vedio1=$_FILES['vedio1']['name']; move_uploaded_file($_FILES['vedio1']['tmp_name'],$path11.$vedio1); }


$rs=$obj->update_topicwise_video($class,$subject,$chapter,$topic,$video_name,$thaminal1,$vedio1,$id);
if($rs)
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('insert success');
          window.location.href='topic_wise_list.php';
       </script>");
}
else
{
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('insert not success');
          window.location.href='topic_wise_list.php';
       </script>");
}
?>


