<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

    $id=$_GET['id'];
    $status=$_GET['status'];
    $us=$obj->update_video_free_video_3($id,$status);

?>

 <div class="panel-body">
                                        <div class="table-responsive">
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th></th>
													 <th>Class</th>
													  <th>Subject</th>
													  	<th>Chapter</th>
													  	<th>Topic</th>
														<th>Image</th>
                                                       
                                                        <th style="width:400; ">Contan</th>
														<th>Document</th>
														
                                                        <th>Action</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
												<?php
													$table='topic';
													$rs=$obj->fetchAllDetail($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
																
																$cit=$obj->fetchById($row['class'],"class","id");
																$sch=$obj->fetchById($row['subject'],"subject","id");
																$sch45=$obj->fetchById($row['chapter'],"chapter","id");
															?>
                                                    <tr>

  <td>
<?php  if($row['free_status']=='1'){ ?>
<input type="checkbox"  onclick="change_update('<?php echo $row['id']; ?>','0')" checked="checked">
<?php } else{ ?>

<input type="checkbox"  onclick="change_update('<?php echo $row['id']; ?>','1')"> <?php } ?></td>                                    
                                                        
													<td><?php  echo $cit['class'];?></td>
													<td><?php  echo $sch['subject'];?></td>
													<td><?php  echo $sch45['chapter'];?></td>

														<td><?php  echo $row['topic'];?></td>
														<td><img src="upload/<?php  echo $row['topic_pic'];?>" style="width: 217px; height: 225px;"></td>
													
                                                        <td style="width: 400px; height: 225px;"><?php  echo $row['contant'];?></td>
														<td><a href="upload/<?php  echo $row['doucment'];?>">Doucment Download</a></td>
                                                       
                                                       
                                                       
                                                       <td><div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="topic_edit_new.php/<?php echo $row['id'];?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a></li>
    <li><a href="delete.php/<?php echo $row['id'];?>/topic/id/topic_list" onClick="return confirm('Are you sure?');"><i class="fa fa-trash" aria-hidden="true"></i>Delete</a></li>
   <?php if($row['status']==1){?>
   <li><a href="updateStatus.php/<?php echo $row['id'];?>/0/topic/status/id/topic_list">Deactive</a></li><?php } ?>
	 <?php if($row['status']==0){?><li><a href="updateStatus.php/<?php echo $row['id'];?>/1/topic/status/id/topic_list" >Active</a></li><?php } ?>
  
     </ul>
</div></td>
                                                    </tr>
													<?php }} ?>
                                                  
                                                 
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>