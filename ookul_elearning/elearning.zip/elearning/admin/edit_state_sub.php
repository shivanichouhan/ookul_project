<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$city=$_POST['city'];



$rs=$obj->updatecity($city,$id);
if($rs)
{
	//$_SESSION['msg']=" Update Success Full";
	//header("location:city_list.php");
	
	 echo ("<script LANGUAGE='JavaScript'>
          window.alert(' Update Success Full');
          window.location.href='city_list';
       </script>");
}
else
{
//	$_SESSION['msg']="Update Not Insert";
//	header("location:city_list.php");
	
	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update Not Insert');
          window.location.href='city_list';
       </script>");
	
}
?>