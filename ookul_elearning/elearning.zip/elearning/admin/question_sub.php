<?php
include"../include/database.php";
$obj=new database();

  $state_id=$_POST['state_id'];
 $city=$_POST['city'];

 $school_id=$_POST['school_id'];
 $class_id=$_POST['class_id'];
 $question_1=$_POST['question_1'];
 $question_2=$_POST['question_2'];
 $question_3=$_POST['question_3'];
 $question_4=$_POST['question_4'];


$rs=$obj->insertquestion($state_id,$city,$school_id,$class_id,$question_1,$question_2,$question_3,$question_4);
if($rs)
{
	$_SESSION['msg']=" Insert Success Full";
	header("location:question_list.php");
}
else
{
	$_SESSION['msg']=" Not Insert";
	header("location:question_list.php");
}
?>