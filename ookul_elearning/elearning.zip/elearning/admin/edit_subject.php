<?php include"header.php";
include"menu.php";
$b=explode('/',$a);
 $_GET['id']=$b['6']; 
$subj=$obj->fetchById($_GET['id'],"subject","id");

$cla=$obj->fetchById($subj['class'],"class","id");
 ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Edit Day Wise Subject </h1>
                                <small>Edit Day Wise Subject <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="subject_list">Day Wise Subject List</a></li>
                                    <li class="active">Edit Day Wise Subject</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Day Wise Subject</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form data-toggle="validator" enctype="multipart/form-data" action="<?php echo $base1; ?>edit_subject_sub.php" method="post">
										<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
											<div class="form-group">
                                                <label for="inputName" class="control-label">Class Name</label>
												<select class="form-control" id="exampleSelect1" name="class"  >
												 <option value="">--Class--</option>
												<?php
													$table='class';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($subj['class']==$row['id']) { ?> selected="selected" <?php } ?>  value="<?php echo $row['id']; ?>"><?php echo $row['class'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Subject Name</label>
                                                <input type="text" class="form-control" id="subject" name="subject" placeholder="subject" value="<?php echo $subj['subject']; ?>" >
											</div>
											
									<div class="form-group">
                                    <label for="inputName" class="control-label">Subject Icon</label>
                                    <input type="file" class="form-control" id="subject" name="icon1" >
                                    
                                    <input type="hidden" name="limg1" value="<?php echo $subj['icon1']; ?>" >
									</div>
											
									<div class="form-group">
                                    <label for="inputName" class="control-label">Subject Banner</label>
                                    <input type="file" class="form-control" id="subject" name="images" >
                                    
                                    <input type="hidden" name="limg2" value="<?php echo $subj['banner1']; ?>" >
									</div>
											
											
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Add Subject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->
			 <script>
 function ct(a){
				 //alert(a);
				 $("#city").load("city_Ajax.php?id="+a);
				  }
				  </script>
				  			 <script>
 function sub(a){
				 alert(a);
				 $("#subject").load("subjectAjax.php?id="+a);
				  }
				  </script>
				  			 <script>
 function sc(a){
				// alert(a);
				 $("#school").load("schoolAjax.php?id="+a);
				  }
				  </script>

       <?php include"footer.php"; ?>