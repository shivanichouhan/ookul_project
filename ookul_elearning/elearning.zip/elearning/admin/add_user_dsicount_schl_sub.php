<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");




@$user1=$_POST['user'];
 $user=implode(",",$user1); 
		
$id=$_POST['id'];
  
$rs=$obj->insert_user_discount_update_1_007($user,$id);


if($rs)
{
   
            		
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='discount_coupon_schl_list';
       </script>");
     
  
}
else
{ 
    	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='discount_coupon_schl_list';
       </script>");
    
}
	
?>