<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");


$address1=$web['address'];
$sphone=$web['phone'];
$semail=$web['email'];
$logo=$web['logo'];
$facebook=$web['facebook'];
$google=$web['google'];
$twitter=$web['twitter'];
$web_name=$web['web_name'];
$email_admin=$web['email'];

$user_id=$_POST['user_id'];
$email=$_POST['email'];
$questions=$_POST['questions'];
$answer=$_POST['answer'];
$path2="upload/";
$img=$_FILES['img']['name']; move_uploaded_file($_FILES['img']['tmp_name'],$path2.$img);


$rs=$obj->replay_user_ask_q($user_id,$email,$questions,$answer,$img);
if($rs)
{//	$_SESSION['msg']=" Insert Success Full";
	//header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='replay_user_list';
       </script>");
}
else
{
	//$_SESSION['msg']=" Not Insert";
//	header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='replay_user_list';
       </script>");
}
?>