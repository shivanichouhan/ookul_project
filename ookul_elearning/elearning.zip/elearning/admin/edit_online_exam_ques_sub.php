<?php
include"../include/database.php";
$obj=new database();


$id=$_POST['id'];

$exam_type_id=$_POST['exam_type_id'];

$subject=$_POST['subject'];
//$type=$_POST['type'];

  $question=addslashes($_POST['question']);
 


  $option1=addslashes($_POST['option1']);
  $option2=addslashes($_POST['option2']);
  $option3=addslashes($_POST['option3']);
  $option4=addslashes($_POST['option4']);
  $solution=addslashes($_POST['solution']);

 $answer=$_POST['answer'];
 
 $path1="user_upload/";
if($_FILES['question_image']['name']=="") { $question_image=$_POST['que_limg']; } else { $question_image=$_FILES['question_image']['name']; move_uploaded_file($_FILES['question_image']['tmp_name'],$path1.$question_image); }

$path2="user_upload/";
if($_FILES['option_img1']['name']=="") { $option_img1=$_POST['limg1']; } else { $option_img1=$_FILES['option_img1']['name']; move_uploaded_file($_FILES['option_img1']['tmp_name'],$path2.$option_img1); }

$path3="user_upload/";
if($_FILES['option_img12']['name']=="") { $option_img12=$_POST['limg2']; } else { $option_img12=$_FILES['option_img12']['name']; move_uploaded_file($_FILES['option_img12']['tmp_name'],$path3.$option_img12); }

$path4="user_upload/";
if($_FILES['option_img3']['name']=="") { $option_img3=$_POST['limg3']; } else { $option_img3=$_FILES['option_img3']['name']; move_uploaded_file($_FILES['option_img3']['tmp_name'],$path4.$option_img3); }

$path5="user_upload/";
if($_FILES['option_img4']['name']=="") { $option_img4=$_POST['limg4']; } else { $option_img4=$_FILES['option_img4']['name']; move_uploaded_file($_FILES['option_img4']['tmp_name'],$path5.$option_img4); }

$path6="user_upload/";
if($_FILES['solution1']['name']=="") { $solution1=$_POST['sol_limg']; } else { $solution1=$_FILES['solution1']['name']; move_uploaded_file($_FILES['solution1']['tmp_name'],$path6.$solution1); }

$rs=$obj->update_school_question1($exam_type_id,$subject,$type,$question,$option1,$option2,$option3,$option4,$solution,$question_image,$option_img1,$option_img12,$option_img3,$option_img4,$solution1,$answer,$id);
if($rs)
{
	
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('Upadted Successfully');
          window.location.href='school_mlutipal_question_list';
       </script>");
}
else
{
	
echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Updated');
          window.location.href='school_mlutipal_question_list';
       </script>");
}
?>