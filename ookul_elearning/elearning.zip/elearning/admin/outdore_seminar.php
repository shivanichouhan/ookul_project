<?php  include"header.php"; ?>
<?php  include"menu.php"; ?>             <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Outdoor Seminar</h1>
                                <small></small>
                                <ol class="breadcrumb">
                                    <li><a href="index.html"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Forms</a></li>
                                    <li class="active">Basic Form</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Outdoor Seminar</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                       
                                        <form>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <fieldset>
                                                        <legend> Video </legend>
                                                        <iframe width="560" height="315" src="https://www.youtube.com/embed/5yzUMFWm4Hw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                                                    </fieldset>
                                                </div>
                                                <div class="col-md-4">
                                                   
                                                        Ticket Id 
														</br>
														<a href="" class="btn btn-success">Pyment Now</a>
                                                </div>
                                                 <div class="col-md-4">
                                                   
                                                        <img src="../images/avatar-01.jpg" style="width:50px; ">
														</br>
														<a>Sheetal</a>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                            
                            <!-- Disabled state -->
                            
                            <!-- Control sizing -->
                            
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
            <footer class="main-footer">
                <div class="container">
                    <div class="pull-right hidden-xs"> <b>Version</b> 1.0</div>
                    <strong>Copyright &copy; 2016-2017 <a href="#">Thememinister</a>.</strong> All rights reserved. <i class="fa fa-heart color-green"></i>
                </div>
            </footer> <!-- /. footer -->
        </div> <!-- ./wrapper -->
        <!-- jQuery -->
        <script data-cfasync="false" src="../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->




        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
    </body>

<!-- Mirrored from thememinister.com/bootstrap-admin-template/template/theme/adminpage_v1.0/forms_basic.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 09 Aug 2018 05:44:12 GMT -->
</html>