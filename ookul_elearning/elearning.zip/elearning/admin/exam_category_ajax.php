 
 <?php
include"../include/database.php";
$obj= new database();


	$id=$_GET['id']
?>
	<div class="form-group">
											  <label for="exampleInputEmail1">Sub category </label>

												<select  class="form-control" data-placeholder="Choose a Subcategory..." id="userall"   name="subcategory"  required>
													<option value="">Sub category</option>
													<?php
   $row=$obj->fetchDetailByidByStatus(1,"subcategory_exam_update","status","category",$id);
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>" > <?php echo $rs['subcategory'];?></option>
   <?php }}?>
												</select>
							  
											</div>
	

	  
