

  <option value=""> -- select --</option>
 <?php
include"../include/database.php";
$obj= new database();


//echo $_GET['id']; die();

   $row=$obj->fetchDetailById($_GET['id'],"virtual_lab_subject","class_id");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>"><?php echo $rs['subject'];?></option>
   <?php }}?>