<?php 
include"../include/database.php";
$obj=new database();


$quentitiy=str_replace("'","\'",$_POST['quentitiy']);
for($i=0;$i<$quentitiy;$i++)
{
	$title=str_replace("'", "\'",$_POST['title']);
$class=str_replace("'","\'",$_POST['class']);
$price=str_replace("'","\'",$_POST['price']);


$ptype=$_POST['ptype'];

$start_date=str_replace("'","\'",$_POST['start_date']);
$end_date=str_replace("'","\'",$_POST['end_date']);

	 $code=rand(11111111111111,99999999999999);
	
$rs=$obj->addcoupon($title,$class,$price,$i,$start_date,$end_date,$code,$ptype);
if($rs)
{

	//header("location:coupan.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='coupan';
       </script>");
}
else
{
	//header("location:coupan.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='coupan';
       </script>");
}
}

?>