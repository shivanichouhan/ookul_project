<?php include"header.php";
include"menu.php"; 
$b=explode('/',$a);
 $_GET['id']=$b['6']; 

$school=$obj->fetchById($_GET['id'],"class","id");


?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Class </h1>
                                
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="school_list">Class List</a></li>
                                    <li class="active">Edit Class</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Class</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form data-toggle="validator" action="<?php echo $base1; ?>edit_class_sub.php" method="post">
                                          <input type="hidden" class="form-control" id="inputName" name="id" value="<?php echo $school['id']; ?>" placeholder="id" required>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Class Name</label>
                                                <input type="text" class="form-control" id="inputName" name="class" value="<?php echo $school['class']; ?>" placeholder="school" required>
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Expiry Date</label>
                                                <input type="date" class="form-control" id="inputName" name="expiry_date" value="<?php echo $school['expiry_date']; ?>" placeholder="school" required>
											</div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Edit Class</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->
	

       <?php include"footer.php"; ?>