<?php
include"../include/database.php";
$obj=new database();



$id=$_POST['id'];
$class_id=$_POST['class_id'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
 $question=$_POST['question'];

  $option1=$_POST['option1'];
 $option2=$_POST['option2'];
 $option3=$_POST['option3'];
 $option4=$_POST['option4'];
 $answer=$_POST['answer'];


$rs=$obj->updatequestion_demo($class_id,$subject,$chapter,$question,$option1,$option2,$option3,$option4,$answer,$id);
if($rs)
{
	$_SESSION['msg']=" Update Success Full";
	header("location:demo_mcq_list");
}
else
{
	$_SESSION['msg']=" Not Update";
	header("location:demo_mcq_list");
}
?>