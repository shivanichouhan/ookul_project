<?php include"header.php";
include"menu.php"; 
$con=$obj->fetchById($_GET['id'],"current_affairs_subject","id");
?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Current Affairs Subject</h1>
                                <small>Add Current Affairs Subject</small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="current_affairs_subj_list.php">Current Affairs Subject List</a></li>
                                    <li class="active">Add Current Affairs Subject</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
							<form data-toggle="validator" action="edit_current_affairs_subj_sub.php" method="post" enctype="multipart/form-data">
                       <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" >

                                <div class="panel panel-bd lobidrag">
									
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Current Affairs Subject </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
											
                                            
											
									<div class="form-group">
									<label for="inputName" class="control-label">Subject Name</label>
										<input type="text" name="subject_name" class="form-control"  value="<?php echo $con['subject_name'];?>">
									</div>	
									<div class="form-group">
									<label for="inputName" class="control-label">Image<p  style="background: #da0f3e;  color: #e8dede; ">(200*200)</p></label>
										<input type="file" name="image" class="form-control"  value="<?php echo $con['image'];?>">
									</div>										
										
										<div class="form-group">
										<button type="submit" class="btn btn-primary">Add Current Affairs</button>
										</div>
                                    </div>
                                </div>
								</form>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
       <?php include"footer.php"; ?>
	   <!-- jQuery -->
        