<?php       include"../include/database.php";


$obj= new database();
$web_info=$obj->fetchByIdTable("website_details");
 ?> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4> User List</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                    <tr>
														<th>Name</th>
														<th>Email</th>
														<th>Mobile Number</th>
														<th>Class</th>
														<th>District</th>
														<th>Block</th>
														
														<th>Address</th>
														<th>Gender</th>
														<th>Date Of Birth</th>
														<th>Payment Type</th>
														<th>Register Date</th>
													
														
                                                    </tr>
                                                </thead>
                                                <tbody>
												
 <?php


   $row=$obj->fetchDetailById($_GET['id'],"user_register","city_id");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){
	    
	  $cit=$obj->fetchById($rs['city_id'],"city","id");
	  $block=$obj->fetchById($rs['block'],"block","id");
	    $class12=$obj->fetchById($rs['class'],"class","id");
												?>
                                                    <tr>
													<td><?php echo $rs['name']; ?></td>
													<td><?php echo $rs['email']; ?></td>
													<td><?php echo $rs['mobile']; ?></td>
													<td><?php echo $class12['class']; ?></td>
													
                                                    <td><?php echo $cit['city']; ?></td>
													 <td><?php echo $block['block']; ?></td>
													<td><?php echo $rs['address']; ?></td>
													<td><?php echo $rs['gender']; ?></td>
													<td><?php echo $rs['dob']; ?></td>
													
													<td><?php if($rs['pstatus']==1)
													{
													
														if( $rs['payment_type']==1)
														{
															?>
															<button type="button" class="btn btn-success" style="border-color: #f64565!important;
													background: #f64565;">Paid ( Online )</button>
															<?php
														} 
														elseif( $rs['payment_type']==3)
														{
															?>
															<button type="button" class="btn btn-success" style="border-color: #f64565!important;
													background: #f64565;">Paid ( Coupan )</button>
															<?php
														} 
														
													}
													else
													{
														?>
														<button type="button" class="btn btn-success" style="border-color: #f64565!important;
													background: #f64565;">Unpaid</button>
														<?php
													}
													?></td>
													
													<td><?php echo $rs['register_date']; ?></td>
														
                                                    </tr>
															<?php 
														}
													} ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
        