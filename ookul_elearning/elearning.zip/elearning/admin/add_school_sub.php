<?php
include"../include/database.php";
$obj=new database();


//$state_id=$_POST['state_id'];
//$city=$_POST['city'];
$school=$_POST['school'];
$city=$_POST['city'];
$block=$_POST['block'];


$rs=$obj->insertschool($school,$city,$block);
if($rs)
{
	$_SESSION['msg']=" Insert Success Full";
	header("location:add_school.php");
}
else
{
	$_SESSION['msg']=" Not Insert";
	header("location:add_school.php");
}
?>