<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
 $package_id=$_POST['package_id'];
 $exam_id=$_POST['exam_id'];


$path="upload/";

if($_FILES['pdf11']['name']=="") { $pdf=$_POST['limg']; } else { $pdf=date ( "Y-m-d" ) . "_" . time ()  .$_FILES['pdf11']['name']; move_uploaded_file($_FILES['pdf11']['tmp_name'],$path.$pdf); }

$rs=$obj->updatepdfupload($package_id,$exam_id,$pdf,$id);
if($rs)
{
  $_SESSION['msg']=" Update Success Full";
	header("location:exam_pdf_list.php");

}
else
{
	$_SESSION['msg']=" Not Update";
	header("location:exam_list.php");

}
?>