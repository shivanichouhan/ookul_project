  <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,900&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://rawgit.com/dbrekalo/attire/master/dist/css/build.min.css">
<script src="https://rawgit.com/dbrekalo/attire/master/dist/js/build.min.js"></script>

        <link rel="stylesheet" href="dist/fastselect.min.css">
        <script src="dist/fastselect.standalone.js"></script>

        <style>

            .fstElement { font-size: 1.10em; }
            .fstToggleBtn { min-width: 16.5em; }

            .submitBtn { display: none; }

            .fstMultipleMode { display: block; }
            .fstMultipleMode .fstControls { width: 100%; }

        </style>  
 <?php
include"../include/database.php";
$obj= new database();


?>


<div class="form-group">
<label for="exampleInputEmail1">User</label>
<select class="multipleSelect"  data-placeholder="Choose a city..." id="user"  multiple name="student[]"  required>
<option value="all">User</option>
<?php




   $row=$obj->fetchDetailById($_GET['id'],"user_register","class");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option selected="selected"   value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?></option>
   <?php }}?>
												</select>
							  
											</div>
	 <script>

                $('.multipleSelect').fastselect();

            </script>	 