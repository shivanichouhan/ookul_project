<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");
$id=$_POST['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$mobile=$_POST['mobile'];
$amount=$_POST['amount'];

$distric_id=$_POST['distric_id'];


$address=$_POST['address'];

$adhar_no=$_POST['adhar_no'];

 $account_holder_name=$_POST['account_holder_name'];
 $account_number=$_POST['account_number'];
  $ifc_code=$_POST['ifc_code'];
 $branch_name=$_POST['branch_name'];

$path1="upload/";
 if($_FILES['document']['name']=="") { $img1=$_POST['limg1']; } else { $img1=$_FILES['document']['name']; move_uploaded_file($_FILES['document']['tmp_name'],$path1.$img1); }

$path="upload/";
 if($_FILES['photo']['name']=="") { $img=$_POST['limg']; } else { $img=$_FILES['photo']['name']; move_uploaded_file($_FILES['photo']['tmp_name'],$path.$img); }




$rs=$obj->updatedistricholder($id,$name,$email,$password,$mobile,$amount,$block_supervisor_id,$address,$adhar_no,$account_holder_name,$account_number,$ifc_code,$branch_name,$img,$img1);
if($rs)
{
		echo ("<script LANGUAGE='JavaScript'>
					  window.alert('Assign Distric Holder');
					  window.location.href='distric_holder_list';
				   </script>");

}			
else
{
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Assign  Distric Holder');
          window.location.href='add_distric_holder';
       </script>");
}
?>