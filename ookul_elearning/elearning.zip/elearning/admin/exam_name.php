<?php include"header.php";
include"menu.php"; ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
<h1>Exam Name </h1>
<small>Add Exam Name <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="exam_name_list.php">Exam Name List</a></li>
                                    <li class="active">Exam Name</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Exam Name</h4>
                                        </div>
                                    </div>
                                    
                                    
                                  

                                    
<div class="panel-body">
<form data-toggle="validator" action="exam_name_sub.php" method="post" enctype="multipart/form-data">
    
    
<div class="form-group">
<label for="inputName" class="control-label">Subject Name</label>
									
<select class="form-control" name="subject_id[]" id="class" multiple> 
<option value="">--Subject Name--</option>
<?php
$table='add_subject_exam';
$rs=$obj->fetchAllDetail($table);
if($rs)
{	$i=0;
while($row=mysqli_fetch_assoc($rs))
{	$i++;
      
?>
<option value="<?php echo $row['id']; ?>"><?php echo $row['subject'];  ?></option>
<?php } 
}
?>
</select>
</div>	                                    
                                        
    
    
    
<div class="form-group">
<label for="inputName" class="control-label">Exam Name</label>
<input type="text" class="form-control" id="inputName" name="category" placeholder="Exam" required>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Exam Duration (In minutes)</label>
<input type="text" class="form-control" id="inputName" name="duration" placeholder="Exam Duration" required>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Total Number of attempt</label>
<input type="text" class="form-control" id="inputName" name="type" placeholder="Total Number of attempt" required>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Exam Package</label>
<select class="form-control" id="inputName" name="package" required>
<option value="">--Select Package--</option>
<?php
$table='package';
$rs=$obj->fetchAllDetail($table);
if($rs)
{//	$i=0;
while($row=mysqli_fetch_assoc($rs))
{//	$i++;
?>
<option value="<?php  echo $row['id'];?>"><?php  echo $row['title'];?></option>
<?php }} ?>


</select>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Total No. of Questions</label>
<input type="text" class="form-control" id="inputName" name="question_no" placeholder="Total No. of Questions" required>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Total Marks</label>
<input type="text" class="form-control" id="inputName" name="total_marks" placeholder="Total Marks" required>
</div>


<div class="form-group">
<label for="inputName" class="control-label">Marks per question</label>
<input type="text" class="form-control" id="inputName" name="marks_per_quest" placeholder="Marks per question" required>
</div>


<div class="form-group">
<label for="inputName" class="control-label">Negative Marking</label>
<select class="form-control" id="inputName" name="negative_marking" required>
<option value="">--Select--</option>
<option value="0">3 is to 1</option>
<option value="1">2 is to 1</option>
<option value="2">No Nagative Marking</option>
</select>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Test live Duration</label>
<select class="form-control" id="inputName" name="live_duration" required>
<option value="">--Select--</option>
<option value="0">Unlimited Timing</option>
<option value="1">Limited Timing</option>
</select>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Date of exam</label>
<input type="date" class="form-control" id="inputName" name="dateofexam" required>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Date of expiry</label>
<input type="date" class="form-control" id="inputName" name="edate" required>
</div>

<div class="form-group">
<label for="inputName" class="control-label">Start Time of Exam</label>
<input type="time" class="form-control" id="inputName" name="stime" required>
</div>

<div class="form-group">
<label for="inputName" class="control-label">End Time of Exam</label>
<input type="time" class="form-control" id="inputName" name="etime" required>
</div>
				
<div class="form-group">
<label for="inputName" class="control-label">Image </label>
<input type="file" class="form-control"  name="imagess"  required>
</div>				

<div class="form-group">
<label for="inputName" class="control-label">Description</label>
<textarea id="summernote" name="contant"></textarea>
</div>



<div class="form-group">
<button type="submit" class="btn btn-primary" style="background: -webkit-linear-gradient(left, #ff771c 0%, #ea00ca 50%,#9d09e9 90%);
    border: 1px solid transparent;
    font-weight: 700;">Add Exam Name</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->


       <?php include"footer.php"; ?>