<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

$id=$_POST['id'];
$class=$_POST['class'];
$days=$_POST['days'];
$topic=$_POST['topic'];
$contant=$_POST['contant'];
$path1="upload/";
$topic_pic=$_FILES['topic_pic']['name']; move_uploaded_file($_FILES['topic_pic']['tmp_name'],$path1.$topic_pic);


$path="upload/";
$img=$_FILES['doucment']['name']; move_uploaded_file($_FILES['doucment']['tmp_name'],$path.$img);


$rs=$obj->update_gover_assig($class,$days,$topic,$topic_pic,$img,$contant,$id);

if($rs)
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update success');
          window.location.href='gove_assing_list.php';
       </script>");
}
else
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not update');
          window.location.href='gove_subject.php';
       </script>");
}



?>