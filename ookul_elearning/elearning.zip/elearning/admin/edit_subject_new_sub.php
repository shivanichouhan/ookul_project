<?php
include"../include/database.php";
$obj=new database();



$id=$_POST['id'];

$subject=$_POST['subject'];





$rs=$obj->update_exam_subject___007($subject,$id);


if($rs)
{echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update success');
          window.location.href='new_subject_list';
       </script>");
    
    
    
   
}
else
{
    
    
    echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update');
          window.location.href='new_subject_list';
       </script>");
       
}
?>