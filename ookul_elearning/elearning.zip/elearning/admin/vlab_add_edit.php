<?php include"header.php";
include"menu.php"; 
$b=explode('/',$a);
 $_GET['id']=$b['5'];
$top=$obj->fetchById($_GET['id'],"virtual_lab_topic","id");
$sub=$obj->fetchById($top['subject'],"virtual_lab_subject","id");
?>

            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Virtual Lab </h1>
                                <small>Add Virtual Lab <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="topic_list">Virtual Lab List</a></li>
                                    <li class="active">Virtual Lab</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Virtual Lab</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form  action="<?php echo $base1; ?>vlab_update" method="post" enctype="multipart/form-data">
										<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" >
											<div class="form-group">
                                                <label for="exampleSelect1">Class</label>
												
                                                <select class="form-control"  name="class"  onChange="clas(this.value);">
												 <option value="">--Class--</option>
												<?php
													$table='class';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($top['class']==$row['id'])  { ?> selected="selected"  <?php } ?> value="<?php echo $row['id']; ?>"><?php echo $row['class'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
														
                                            </div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Subject</label>
                                                
													<select class="form-control"  id="subject"  name="subject" required >
														 <option value="<?php echo $top['subject']; ?>"><?php echo $sub['subject']; ?></option>
															</select>
                                            
											</div>					
												<div class="form-group">
                                                <label for="inputName" class="control-label">Title</label>
                                                <input type="text" class="form-control"  name="title" placeholder="title" value="<?php echo $top['title']; ?>" required>
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Thumbnail </label>
                                                <input type="file" class="form-control"  name="thumbnail" placeholder="thumbnail" >
                                                	<input type="hidden" class="form-control" name="thumbnail2" value="<?php echo $top['thumbnail'];?>">
                                                	<img  src="<?php echo $base1; ?>upload/Virtual_lab/<?php echo $top['thumbnail']; ?>" style="width:100px;">
										
											</div>
													<div class="form-group">
                                                <label for="exampleSelect1">Type</label>
												
                                                <select class="form-control" id="exampleSelect1" name="type"  >
												 <option value="">--Type--</option>
												<option <?php if($top['type']=='1') { echo"selected"; } ?> value="1">HTML</option>
												<option <?php if($top['type']=='2') { echo"selected"; } ?> value="2">SWF</option>
                                                </select>
														
                                            </div>
												<div class="form-group">
            									<label for="inputName" class="control-label">File name</label>
            										<input type="text" name="file_name" class="form-control" value="<?php echo $top['file_name']; ?>">
            									</div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Update </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->
	 <script>
 function clas(a){
				 //alert(a);
				 $("#subject").load("subjectAjaxvlab.php?id="+a);
				  }
				  </script>
				 
						
				
       <?php include"footer.php"; ?>
       				