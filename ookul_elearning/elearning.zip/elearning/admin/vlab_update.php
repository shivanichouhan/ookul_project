<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

 $id=$_POST['id'];
$class=$_POST['class'];
$subject=$_POST['subject'];
$title=$_POST['title'];
$type=$_POST['type'];
$file_name=$_POST['file_name'];
$path1="upload/Virtual_lab/";

 if($_FILES['thumbnail']['name']=="") { $thumbnail=$_POST['thumbnail2']; } else { $thumbnail=$_FILES['thumbnail']['name']; move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path1.$thumbnail); }





$rs=$obj->update_Virtual_lab_01($class,$subject,$title,$type,$file_name,$thumbnail,$id);

if($rs)
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert success');
          window.location.href='vlab_list';
       </script>");
}
else
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not insert');
          window.location.href='vlab_list';
       </script>");
}



?>