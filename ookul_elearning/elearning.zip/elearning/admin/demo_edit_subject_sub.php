<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];

$class=$_POST['class'];
$subject=$_POST['subject'];



$rs=$obj->demo_update_subject($class,$subject,$id);
if($rs)
{
//	$_SESSION['msg']=" Update Success Full";
//	header("location:demo_subject_list.php");
		 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update Success Full');
          window.location.href='demo_subject_list';
       </script>");
}
else
{

		 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update');
          window.location.href='demo_subject_list';
       </script>");
}
?>