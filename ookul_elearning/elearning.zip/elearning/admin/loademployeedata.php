<?php
include"../include/database.php";
$obj=new database();


?>  
<!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Report/History</h4>
                                        </div>
                                    </div>
									
                                    <div class="panel-body">
                                       <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                   <tr>
													<th>#</th>
														<th>Name</th>
														<th>Email</th>
														<th>Mobile Number</th>
														<th>Session Expiry Date</th>
														<th>District</th>
														<th>Block</th>														
														<th>Address</th>
														<th>Gender</th>
														<th>Date Of Birth</th>
														<th>Profile</th>
														<th>Make Address</th>
														<th>Payment Type</th>
													
														<th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
												
															<?php
															$city_id = $_GET['city_id'];
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server..
$db = mysql_select_db("elearning_portel_update", $connection); // Selecting Database
$i=0;
if (isset($city_id)) {
    $query = " SELECT * FROM user_register WHERE city_id = '$city_id'";
    $result = mysql_query($query);
   
    while($row = mysql_fetch_object($result)){

        echo '<tr>'
		.'<td>'.$row->$i++.'</td>'
            .'<td>'.$row->name.'</td>'
            .'<td>'.$row->email.'</td>'
            .'<td>'.$row->mobile.'</td>'
			.'<td>'.$row->expriy_date.'</td>'
			.'<td>'.$row->city_id.'</td>'
			.'<td>'.$row->block.'</td>'
			 .'<td>'.$row->address.'</td>'
			 .'<td>'.$row->gender.'</td>'
			 .'<td>'.$row->dob.'</td>'
			    .'<td><img src="upload/'.$row->photo.'" style="width: 50px; height: 50px;"></td>'
			   .'<td>'.$row->make_address.'</td>'
			      .'<td>'.$row->payment_type.'</td>'
			 
				 .'<td><div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action
  <span class="caret"></span></button>
    
</div></td>'.
            '</tr>';
    }
   
}

?>
                                                     
                                                 
                                                </tbody>
												<?php mysql_close($connection); // Connection Closed ?>
                                            </table>
                                        </div>
                                    </div>
                               