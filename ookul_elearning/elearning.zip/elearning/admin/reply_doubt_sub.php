<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$reply=$_POST['reply'];




$path="gov_upload/";


$pdf=$_FILES['imagess']['name']; move_uploaded_file($_FILES['imagess']['tmp_name'],$path.$pdf); 

$rs=$obj->updateanswer_007($reply,$pdf,$id);
if($rs)
{
//	$_SESSION['msg']=" Update Success Full";
//	header("location:question_answer_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='doubt_clearance_list';
       </script>");
}
else
{
	//$_SESSION['msg']=" Not Update";
//	header("location:question_answer_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='doubt_clearance_list';
       </script>");
}
?>