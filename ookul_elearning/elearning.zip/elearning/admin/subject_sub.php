<?php
include"../include/database.php";
$obj=new database();

$subject=$_POST['subject'];

$path1="gov_upload/";
$img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path1.$img);

$path2="gov_upload/";
$banner_image=$_FILES['banner_image']['name']; move_uploaded_file($_FILES['banner_image']['tmp_name'],$path2.$banner_image);
$rs=$obj->insert_subject_gov($subject,$img,$banner_image);
if($rs)
{
	
	header("location:subject.php");
	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Success');
          window.location.href='subject';
       </script>");
}
else
{
	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Success');
          window.location.href='subject';
       </script>");

}
?>