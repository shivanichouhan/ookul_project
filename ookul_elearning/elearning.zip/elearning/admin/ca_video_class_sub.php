<?php
include"../include/database.php";
$obj=new database();

//$subject=htmlspecialchars($_POST['subject']);
$subject=$_POST['subject'];
$topic=$_POST['topic'];
$title=$_POST['title'];

$path1="gov_upload/";
$img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path1.$img);


$path2="gov_upload/";
$video=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path2.$video);

$rs=$obj->ca_video_class($subject,$topic,$img,$video,$title);
if($rs)
{
	

			echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert Success Full');
          window.location.href='gov_assigment';
       </script>");
}
else
{
	
			echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert Not Success Full');
          window.location.href='ca_video_class';
       </script>");
}
?>