<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$gst=$_POST['gst'];
$class=$_POST['class'];
$price=$_POST['price'];

$nprice=$_POST['nprice'];
$ngst=$_POST['ngst'];


$rs=$obj->update_price($class,$price,$gst,$nprice,$ngst,$id); 

//update_price($gst,$class,$price,$id);
if($rs)
{
	//$_SESSION['msg']=" Update Success Full";
	//header("location:price_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='price_list.php';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Update";
//	header("location:price_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='price_list.php';
       </script>");
}
?>