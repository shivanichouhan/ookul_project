<?php

include_once("../include/database.php");
$obj= new database();

$id=$_GET['id'];


?>
<option value="">--topic--</option>
<?php
$rs=$obj->fetchDetailById($id,"day_wise_topic","subject");
if($rs)
{	$i=0;
while($row=mysqli_fetch_assoc($rs))
{	$i++;

?>
<option value="<?php echo $row['id']; ?>"><?php echo $row['topic'];  ?></option>
<?php } 
}
?>
