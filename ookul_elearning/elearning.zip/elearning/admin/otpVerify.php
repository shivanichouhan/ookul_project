 <?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");
 $otp=$_POST['otp'];


$ii=$obj->fetchByIdByStatus($otp,"coupan_otp","otp","status",0);
if($ii)
{
 $coupan=$ii['coupan'];
$ii8777=$obj->fetchById($coupan,"asign_coupan","id");
 $r00=$obj->updateStatus($coupan,"asign_coupan","status",1,"id");
 

  $u=explode(",",$ii8777['coupan']);
	foreach($u as $uu =>$value)
		{
			//echo $u[$uu];
			
			$r=$obj->updateStatus0000002($u[$uu],"coupan_class","asign",1,"id");
			if($r)
			{
				$_SESSION['msg']="Assign Coupon Successfull";
				header("location:relasedcoupan.php");
			}
			else {
				$_SESSION['msg']="Assign Coupon Successfull ";
				header("location:relasedcoupan.php");
			}
		}
	
}
else 
{
	$_SESSION['msg']="Check Otp try again";
	header("location:otpasin.php");
}

	?>