<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

$name=$_POST['topic'];
$contant=$_POST['contant'];
$amount=$_POST['amount'];



$package_type=$_POST['package_type'];
$package_duration=$_POST['package_duration'];
$date=$_POST['date'];


$path1="upload/";
$img=$_FILES['topic_pic']['name']; move_uploaded_file($_FILES['topic_pic']['tmp_name'],$path1.$img);



$rs=$obj->insertexampackages0007($name,$contant,$img,$amount,$package_type,$package_duration,$date);
if($rs)
{
	
				
		echo ("<script LANGUAGE='JavaScript'>
					  window.alert('Insert Success');
					  window.location.href='exams_packages';
				   </script>");
}
else
{
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert Not  Successfull');
          window.location.href='exams_packages';
       </script>");
}
?>