<?php include"header.php";
include"menu.php"; 

$que=$obj->fetchById($_GET['id'],"gover_multiple_question","id");
$que12=$obj->fetchById($que['days'],"days","id");
$que102=$obj->fetchById($que12['exam_type'],"exam_type","id");

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1> Online Question And Answer </h1>
                                <small>Online Question <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="mlutipal_question_list.php"> Online Question List</a></li>
                                    <li class="active"> Online Question</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Online Question Answer</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                       
                                        <form data-toggle="validator" action="gover_edit_multipal_question_sub.php" method="post">
											<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
											
											<div class="form-group">
                                                <label for="exampleSelect1">Exam Type</label>
												
                                                <select class="form-control" id="exampleSelect1" name="exam_type_id" >
												 <option value="">--Exam Type--</option>
												<?php
													$table='exam_type';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($que102['exam_type_id']==$row['id']) { ?> selected="selected"  <?php } ?> value="<?php echo $row['id']; ?>"><?php echo $row['exam_type'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
														
                                            </div>
											
											
											<div class="form-group">
                                                <label for="exampleSelect1">Class</label>
												
                                                <select class="form-control" id="exampleSelect1" name="class_id"  onChange="clas(this.value);">
												 <option value="">--Class--</option>
												<?php
													$table='gove_class';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($que['class_id']==$row['id']) { ?> selected="selected"  <?php } ?> value="<?php echo $row['id']; ?>"><?php echo $row['class'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
														
                                            </div>
											
											<div class="form-group">
                                                <label for="exampleSelect1">Days</label>
												
                                                <select class="form-control" id="exampleSelect1" name="days_id" >
												 <option value="">--days--</option>
												<?php
													$table='days';
													$rs=$obj->fetchAllDetail($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($que102['days_id']==$row['id']) { ?> selected="selected"  <?php } ?> value="<?php echo $row['id']; ?>"><?php echo $row['days'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
														
                                            </div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Type</label>
                                                
												
												
												  <select class="form-control" id="exampleSelect1" name="type"  onChange="qimage(this.value);" value="<?php  echo $que['type'] ?>">
												 <option value="">--Type--</option>
												<option value="1">Text</option>
												<option value="2">Image</option>
                                                </select>
											</div>
											
											
<div class="form-group">
     <label for="inputName" class="control-label">Question</label>
        <input type="text" class="form-control" id="inputName" name="question" placeholder="question" value="<?php  echo $que['question'] ?>" required>
</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">option(1)</label>
                                                <input type="text" class="form-control" id="inputName" name="option1" placeholder="option 1" value="<?php  echo $que['option1'] ?>"  required>
											</div>
											
											<div class="form-group">
                                                <label for="inputName" class="control-label">option(2)</label>
                                                <input type="text" class="form-control" id="inputName" name="option2" value="<?php  echo $que['option2'] ?>"  placeholder="option 2" required>
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">option(3)</label>
                                                <input type="text" class="form-control" id="inputName" value="<?php  echo $que['option3'] ?>"  name="option3" placeholder="option 3" required>
											</div>
                                            
											<div class="form-group">
                                                <label for="inputName" class="control-label">option(4)</label>
                                                <input type="text" class="form-control" id="inputName" name="option4" placeholder="option 4" value="<?php  echo $que['option4'] ?>"  required>
											</div>
                                           <div class="form-group">
                                                <label for="inputName" class="control-label">Answer</label>
                                              
												<select class="form-control" id="exampleSelect1" name="answer" >
													<option value="">Answer</option>
												    <option <?php if($que['answer']==1) { ?> selected="selected" <?php } ?> value="1" >Question1 </option>
												    <option <?php if($que['answer']==2) { ?> selected="selected" <?php } ?> value="2">Question2</option>
												    <option <?php if($que['answer']==3) { ?> selected="selected" <?php } ?> value="3">Question3</option>
												    <option <?php if($que['answer']==4) { ?> selected="selected" <?php } ?> value="4">Question4</option>
                                                </select>
											</div>
                                             
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->
		  					 <script>
 function clas(a){
				 //alert(a);
				 $("#subject").load("subjectAjax.php?id="+a);
				  }
				  </script>
				  	 <script>
 function subj(a){
				// alert(a);
				 $("#chapter").load("chapterAjax.php?id="+a);
				  }
				  </script>
				  

       <?php include"footer.php"; ?>