<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$exam_type=$_POST['exam_type'];



$rs=$obj->update_exam_type($exam_type,$id);
if($rs)
{
	//$_SESSION['msg']=" Insert Success Full";
//	header("location:price.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('update Success Full');
          window.location.href='exam_type_list.php';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Insert";
//	header("location:price.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert(' not update');
          window.location.href='exam_type_list.php';
       </script>");
}
?>