  
 <?php
include"../include/database.php";
$obj= new database();


?>


<div class="form-group">
											  <label for="exampleInputEmail1">Agent</label>

												<select class="form-control select2" data-placeholder="Choose a city..."   multiple name="agent[]"  required>
													<option value="all">Agent</option>
													<?php




   $row=$obj->fetchAllDetail("agent");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option selected="selected"   value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?></option>
   <?php }}?>
												</select>
							  
											</div>
											<div class="form-group">
											  <label for="exampleInputEmail1">Sub Agent</label>

												<select class="form-control select2" data-placeholder="Choose a city..."   multiple name="subagent[]"  required>
													<option value="all">Sub Agent</option>
													<?php




   $row=$obj->fetchAllDetail("subagent");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option selected="selected"   value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?></option>
   <?php }}?>
												</select>
							  
											</div>

											<div class="form-group">
											  <label for="exampleInputEmail1">User</label>

												<select class="form-control select2" data-placeholder="Choose a city..."  multiple name="11[]"  required>
													<option value="all">User</option>
													<?php




   $row=$obj->fetchAllDetail("user_register");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option selected="selected"   value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?></option>
   <?php }}?>
												</select>
							  
											</div>