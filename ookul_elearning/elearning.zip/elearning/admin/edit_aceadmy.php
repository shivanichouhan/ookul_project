<?php include"header.php";
include"menu.php"; 
$b=explode('/',$a);
 $_GET['id']=$b['5']; 

$acdm=$obj->fetchById($_GET['id'],"academic_year","id");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Academic Year </h1>
                                <small>Edit Academic Year <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="academy_list">Academic Year List</a></li>
                                    <li class="active">Academic Year</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Academic Year</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form data-toggle="validator" action="<?php echo $base1; ?>edit_academic_sub" method="post">
										<input type="hidden" name="id" value="<?php  echo $_GET['id']; ?>">
											<div class="form-group">
<label for="exampleInputEmail1">Class</label>

<select class="form-control" data-placeholder="Choose a city..." id="class" name="class"  required="">
<option value="">Class</option>
    <option <?php if($acdm['class']==1){ ?>selected="selected" <?php } ?> value="1">9th</option>
       <option <?php if($acdm['class']==2){ ?>selected="selected" <?php } ?> value="2">10th</option>
       <option <?php if($acdm['class']==5){ ?>selected="selected" <?php } ?> value="5">8th</option>
       <option <?php if($acdm['class']==6){ ?>selected="selected" <?php } ?> value="6">7th</option>
   
</select>
							  

</div>
									
											<div class="form-group">
                                                <label for="inputName" class="control-label">Year Name</label>
                                                <input type="text" class="form-control" id="inputName" name="name_year" placeholder="Year Name " value="<?php echo $acdm['name_year']; ?>" required>
											</div>
											
											<div class="form-group">
                                                <label for="inputName" class="control-label">Start Date</label>
                                                <input type="date" class="form-control" id="inputName" name="start_year" placeholder="start_year" required value="<?php echo $acdm['start_year']; ?>">
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">End Date </label>
                                                <input type="date" class="form-control" id="inputName" name="end_date" placeholder="end_date" required value="<?php echo $acdm['end_date']; ?>">
											</div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Add Academic Year</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->



       <?php include"footer.php"; ?>