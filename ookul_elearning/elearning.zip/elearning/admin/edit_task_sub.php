<?php
include"../include/database.php";
$obj=new database();


$id=$_POST['id'];
$add_task=$_POST['add_task'];



$rs=$obj->update_add_task($add_task,$id);
if($rs)
{
	//$_SESSION['msg']=" Insert Success Full";
//	header("location:price.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='task_list.php';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Insert";
//	header("location:price.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='task_list.php';
       </script>");
}
?>