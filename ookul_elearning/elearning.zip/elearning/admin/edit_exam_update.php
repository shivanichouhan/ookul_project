<?php include"header.php";
include"menu.php";

$b=explode('/',$a);
 $_GET['id']=$b['5']; 
$suss=$obj->fetchById($_GET['id'],"exam_update","id");
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                               <i class="fa fa-refresh" aria-hidden="true"></i>
                            </div>
                            <div class="header-title">
                                <h1>Exam Update </h1>
                                <small>Exam Update  <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="exam_update_list"> Exam update List</a></li>
                                    <li class="active">Exam update</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Exam Update</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form data-toggle="validator" action="<?php echo $base1; ?>edit_exam_update_sub" method="post" enctype="multipart/form-data" >
                                            <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
											<div class="form-group">
                                                <label for="exampleSelect1">Exam Update category</label>
												
												<select class="form-control" id="exampleSelect1" name="category"  onChange="sss(this.value);">
													 <option value="">--Select--</option>
													 <?php
													$table='category_exam_update';
													$rs8=$obj->fetchDetailById(1,$table,"status");
													if($rs8)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs8))
														{ ?>
													 <option <?php if($suss['category']==$row['id']){  ?> selected="selected" <?php } ?>value="<?php echo $row['id']; ?>"><?php echo $row['category']; ?></option>
													 
												<?php }} ?>	
													 
													
													</select>
														
                                            </div>
                                            <div class="form-group" id="class">
                                                <label for="exampleSelect1">Exam Update category</label>
												
												<select class="form-control" id="exampleSelect1" name="subcategory"  >
													 <option value="">--Select--</option>
													 <?php
												
													$rs7=$obj->fetchById($suss['subcategory'],"subcategory_exam_update","id");
													?>
													 <option  selected="selected" value="<?php echo $rs7['id']; ?>"><?php echo $rs7['subcategory']; ?></option>
													 
												
													 
													
													</select>
														
                                            </div>
											<div class="form-group" id="class">	
							  
											</div>
											
											<div class="form-group">
                                                <label for="inputName" class="control-label">Title</label>
                                                <input type="text" class="form-control" id="inputName" name="title" placeholder="title" value="<?php echo $suss['title']; ?>" required>
											</div>
                                            <div class="form-group">
                                                <label for="inputName" class="control-label">Discription</label>
                                               <textarea id="summernote" name="discription"><?php echo $suss['discription']; ?></textarea>
				                                     </div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">URL</label>
                                                <input type="text" class="form-control" id="inputName" name="url" placeholder="Please Enter URL" value="<?php echo $suss['url']; ?>" >
											</div>
											
											
											
											
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary" style="    background: -webkit-linear-gradient(left, #ff771c 0%, #ea00ca 50%,#9d09e9 90%);
    border: 1px solid transparent;
    font-weight: 700;">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> 
            
            
            <!-- /.
			-wrapper -->
            <!-- start footer -->
			 
				   <script>
 function sss(a){
				//alert(a);
				 $("#class").load("https://app.bongosikha.com/admin/exam_category_ajax.php?id="+a);
				  }
</script>
		   


				  

       <?php include"footer.php"; ?>