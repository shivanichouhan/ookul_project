<?php

include_once("../include/database.php");
$obj= new database();
$info=array();
$response["otp12"] = array();
  $otp=$_POST['otp'];
$rs=$obj->fetchDetailById($otp,"mobile_otp","otp"); 
if($rs)
{
while($row=mysqli_fetch_assoc($rs))
{ 
$response["error"] =false;
$response["success"] =1;
$response["msg"] = "Mobile OTP Conforim";
$info["id"]=$row['id'];
$info["mobile"] = $row['mobile'];
array_push($response["otp12"], $info);
}
echo json_encode($response);
}
else
{
$response["msg"] = "No record Found";
$response["error"] =true;
$response["success"] =0;
array_push($response["otp12"], $info);
echo json_encode($response);
}
?>