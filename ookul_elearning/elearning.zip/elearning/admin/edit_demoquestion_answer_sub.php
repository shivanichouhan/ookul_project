<?php
include"../include/database.php";
$obj=new database();

 $id=$_POST['id'];
$class_id=$_POST['class_id'];

$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
$question=$_POST['question'];
$answer=$_POST['answer'];


$rs=$obj->demo_insertanswer_update($class_id,$subject,$chapter,$question,$answer,$id);
if($rs)
{
	//$_SESSION['msg']=" Insert Success Full";
//	header("location:demo_question_answer_list.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_question_answer_list';
       </script>");
}
else
{
	//$_SESSION['msg']=" Not Insert";
	//header("location:demo_question_answer_list.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_question_answer_list';
       </script>");
}
?>