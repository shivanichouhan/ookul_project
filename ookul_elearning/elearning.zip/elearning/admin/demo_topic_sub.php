<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");


 $class=$_POST['class'];
 $subject=$_POST['subject'];
 $chapter=$_POST['chapter'];
 $topic=$_POST['topic'];
 $contant=$_POST['contant'];

$path1="upload/";
 $topic_pic=$_FILES['topic_pic']['name']; move_uploaded_file($_FILES['topic_pic']['tmp_name'],$path1.$topic_pic);


$path="upload/";
$img=$_FILES['doucment']['name']; move_uploaded_file($_FILES['doucment']['tmp_name'],$path.$img);

$path="upload/";
$video_path=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path.$video_path);





$rs=$obj->demo_insert_topic($class,$subject,$chapter,$topic,$topic_pic,$img,$video_path,$contant);




if($rs)
{
	$_SESSION['msg']=" Topic uploaded ";
	header("location:demo_topic.php");
}
else
{
	$_SESSION['msg']=" Not insert";
	header("location:demo_topic.php");
}





?>