<?php include"header.php";
include"menu.php"; 
$b=explode('/',$a);
 $_GET['id']=$b['5'];
$que=$obj->fetchById($_GET['id'],"user_multiple_questions","id");
 //$que12=$obj->fetchById($que['exam_type_id'],"gove_exam","id");
 $que102=$obj->fetchById($que['subject'],"add_subject_exam","id");

?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1> Edit Question And Answer </h1>
                                <small>Online Practise Question <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="add_quest_ans.php"> Add Question and Answer</a></li>
                                    <li class="active"> Edit Question & Answer</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Question Answer</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                    <form data-toggle="validator" action="<?php echo $base1; ?>edit_online_exam_sub"  enctype="multipart/form-data" method="post">
											
											<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
											
									<div class="form-group">
									<label for="inputName" class="control-label">Exam Name</label>
									
									<select class="form-control" id="exampleSelect1" name="exam_type_id" onChange="msubject(this.value)" >
												 <option value="">--Exam Type--</option>
												<?php
													$table='exam_names';
													$rs=$obj->fetchAllDetail($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($que['exam_id']==$row['id']) { ?> selected="selected" <?php }  ?> value="<?php echo $row['id']; ?>"><?php echo $row['category'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
										</div>
											<div class="form-group">
									<label for="inputName" class="control-label">Subject</label>
									
									<select class="form-control"  name="subject" >
									    
									   <?php
													$table='add_subject_exam';
													$rss=$obj->fetchAllDetail($table);
													if($rss)
													{	$i=0;
														while($rows=mysqli_fetch_assoc($rss))
														{	$i++;
      
															?>
      <option <?php if($que['subject_id']==$rows['id']) { ?> selected="selected" <?php }  ?> value="<?php echo $rows['id']; ?>"><?php echo $rows['subject'];  ?></option>
													<?php } 
													}
													?>
													
									    
												 <option value="<?php echo $que['subject_id']; ?>"><?php echo $que102['subject']; ?></option>
										
                                                </select>
										</div>	
										
											
										
											    
<div class="form-group">
     <label for="inputName" class="control-label">Question</label>
     <textarea id="summernote" name="question"><?php echo $que['question']; ?></textarea>
        <!--<input type="text" class="form-control" id="inputName" name="question" placeholder="question" required>-->
</div>
<div class="form-group">
     <label for="inputName" class="control-label">Question</label>
     <img src="../user_upload/<?php echo $que['question_image']; ?>" width="200px">
        <input type="file" class="form-control" id="inputName" name="question_image" placeholder="question" >
<input type="hidden" name="que_limg" value="<?php echo $que['question_image']; ?>" >        
        
        
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(1)</label>
         <textarea id="summernote1" name="option1"><?php echo $que['option1']; ?></textarea>

    <!--<input type="text" class="form-control" id="inputName" name="option1" placeholder="option 1" required>-->
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(1)</label>
     <img src="../user_upload/<?php echo $que['option_img1']; ?>" width="200px">
    <input type="file" class="form-control" id="inputName" name="option_img1">
    <input type="hidden" name="limg1" value="<?php echo $que['option_img1']; ?>" >
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(2)</label>
    <textarea id="summernote2" name="option2"><?php echo $que['option2']; ?></textarea>
    <!--<input type="text" class="form-control" id="inputName" name="option2" placeholder="option 2" required>-->
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(2)</label>
    <img src="../user_upload/<?php echo $que['option_img12']; ?>" width="200px">
    <input type="file" class="form-control" id="inputName" name="option_img12" >
    <input type="hidden" name="limg2" value="<?php echo $que['option_img12']; ?>" >
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(3)</label>
        <textarea id="summernote3" name="option3"><?php echo $que['option3']; ?></textarea>

    <!--<input type="text" class="form-control" id="inputName" name="option3" placeholder="option 3" required>-->
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(3)</label>
     <img src="../user_upload/<?php echo $que['option_img3']; ?>" width="200px">
    <input type="file" class="form-control" id="inputName" name="option_img3">
    <input type="hidden" name="limg3" value="<?php echo $que['option_img3']; ?>" >
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(4)</label>
       <textarea id="summernote4" name="option4"><?php echo $que['option4']; ?></textarea>
    <!--<input type="text" class="form-control" id="inputName" name="option4" placeholder="option 4" required>-->
</div>
<div class="form-group">
    <label for="inputName" class="control-label">option(4)</label>
     <img src="../user_upload/<?php echo $que['option_img4']; ?>" width="200px">
    <input type="file" class="form-control" id="inputName" name="option_img4" >
     <input type="hidden" name="limg4" value="<?php echo $que['option_img4']; ?>" >
</div>
<div class="form-group">
    <label for="inputName" class="control-label">Solution</label>
           <textarea id="summernote5" name="solution"><?php echo $que['solution']; ?></textarea>

    <!--<input type="text" class="form-control" id="inputName" name="soluction" placeholder="soluction" required>-->
</div>
<div class="form-group">
   
    <label for="inputName" class="control-label">Solution</label>
       <img src="../user_upload/<?php echo $que['solution1']; ?>" width="200px">
    <input type="file" class="form-control" id="inputName" name="solution1">
      <input type="hidden" name="sol_limg" value="<?php echo $que['solution1']; ?>" >
</div>
<div class="form-group">
    <label for="inputName" class="control-label">Answer</label>
		<select class="form-control" id="exampleSelect1" name="answer" >
		<option value="">Answer</option>
		<option <?php if($que['answer']=='1') { ?> selected="selected" <?php }  ?> value="1">Answer 1 </option>
		<option <?php if($que['answer']=='2') { ?> selected="selected" <?php }  ?> value="2">Answer 2</option>
		<option <?php if($que['answer']=='3') { ?> selected="selected" <?php }  ?> value="3">Answer 3</option>
		<option <?php if($que['answer']=='4') { ?> selected="selected" <?php }  ?> value="4">Answer 4</option>
    </select>
</div>

	</div>
											 
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div> 
				</div> 
<script>
 function qimage(a){
				 //alert(a);
				// $("#mcqimage").load("gove_mcq_image_new.php?id="+a);
			//	  }
</script>
		  	<script>

			//	 function msubject(a)
				 {
			//	          var http=new XMLHttpRequest();
			//			http.onreadystatechange=function()
//{	
			//			if(http.readyState==4 && http.status==200)
			//			{
			//		 	document.getElementById("sub").innerHTML=http.responseText;
			//			}
						//alert(http.responseText);
			//			}
						
			//			http.open("GET","examsubajax.php?id="+a,true);
			//			http.send();
			//	 }
				  </script>
				    <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>
        <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote1').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>
        <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote2').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>
        <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote3').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>
        <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote4').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>
        <script>
            $(document).ready(function () {
                "use strict"; // Start of use strict
                //summernote
                $('#summernote5').summernote({
                    height: 300, // set editor height
                    minHeight: null, // set minimum height of editor
                    maxHeight: null, // set maximum height of editor
                    focus: true                  // set focus to editable area after initializing summernote
                });
            });
        </script>

       <?php include"footer.php"; ?>