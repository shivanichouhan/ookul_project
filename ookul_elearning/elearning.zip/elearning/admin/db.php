<?php 
$host = "localhost"; /* Host name */
$user = "bongosikha_bongosikha"; /* User */
$password = "fggfi9478bng"; /* Password */
$dbname = "bongosikha_bongosikha"; /* Database name */

$con = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
?>

