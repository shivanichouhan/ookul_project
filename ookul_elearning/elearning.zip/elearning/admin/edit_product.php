<?php include"header.php";
include"menu.php";
$b=explode('/',$a);
 $_GET['id']=$b['5']; 

$iop=$obj->fetchById($_GET['id'],"shopping_product","id");

?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Product</h1>
                                <small>Edit Product</small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="product_list">Product List</a></li>
                                    <li class="active">Edit Product</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
							<form data-toggle="validator" action="<?php echo $base1; ?>edit_product_sub" method="post" enctype="multipart/form-data">
                        
                                <div class="panel panel-bd lobidrag">
									
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Product </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
									<input type="hidden"  class="form-control" name="id" value="<?php echo $_GET['id']; ?>">
									 <div class="form-group">
                                                <label for="exampleSelect1">Category</label>
												
                                            <select class="form-control" id="exampleSelect1" name="category">
												 <option value="">Category</option>
												<?php
													$table='category_add';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($iop['category']==$row['id']) {?> selected="selected" <?php } ?> value="<?php echo $row['id']; ?>"><?php echo $row['category'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
														
                                            </div>
									<div class="form-group">
										<label for="inputName" class="control-label">Product</label>
										<input type="text"  class="form-control" name="product" value="<?php echo $iop['product']; ?>">
										</div>
										<div class="form-group">
										<label for="inputName" class="control-label">Product Image</label>
										<input type="file"  class="form-control" name="image">
										<input type="hidden" class="form-control" name="limg" value="<?php echo $iop['image'];?>">
										</div>
									<div class="form-group">
										<label for="inputName" class="control-label">Price</label>
										<input type="text"  class="form-control" name="price" value="<?php echo $iop['price']; ?>">
									</div>
									<div class="form-group">
										<label for="inputName" class="control-label">Discount Type</label>
										<input type="radio"  checked="checked" name="discount_type" value="1">Fix
										<input type="radio"   checked="checked" name="discount_type" value="2">Percentage
									</div>	
									<div class="form-group">
										<label for="inputName" class="control-label">Discount Amount</label>
										<input type="text"  class="form-control" name="discount_amount" value="<?php  echo $iop['discount_amount'];  ?>">
									</div>										
									
																	
									<div class="form-group">
										<label for="inputName" class="control-label">Contant</label>
										<textarea id="summernote" name="contant"><?php echo $iop['contant']; ?></textarea>
										</div>
										<div class="form-group">
										<button type="submit" class="btn btn-primary">Add Product</button>
										</div>
                                    </div>
                                </div>
								</form>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
				 <script>
 function ct(a){
				 //alert(a);
				 $("#city").load("city_Ajax.php?id="+a);
				  }
				  </script>
				  			 <script>
 function sub(a){
				 //alert(a);
				 $("#subject").load("subjectAjax.php?id="+a);
				  }
				  </script>
				  			 <script>
 function sc(a){
				// alert(a);
				 $("#school").load("schoolAjax.php?id="+a);
				  }
				  </script>
				  	 <script>
 function subjec(a){
				 alert(a);
				 $("#subject1").load("subject_fetchingAjax.php?id="+a);
				  }
				  </script>
			
       <?php include"footer.php"; ?>