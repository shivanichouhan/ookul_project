<?php
include"../include/database.php";
$obj=new database();

$class_id=$_POST['class_id'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
 $question=$_POST['question'];
 $answer=$_POST['answer'];


$rs=$obj->demoquestiontruefalse($class_id,$subject,$chapter,$question,$answer);
if($rs)
{
	$_SESSION['msg']="Insert Success Full";
	header("location:qtf.php");
}
else
{
	$_SESSION['msg']=" Not Insert";
	header("location:qtf.php");
}
?>