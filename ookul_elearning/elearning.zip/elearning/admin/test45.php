<?php

$otp=rand(1111,9999);

$ot_txt="Hello, Your One Time Password is " .$otp. " . Do not share this OTP to anyone for security reason. Make study easy & fun with Bongosikha.";
$text=urlencode($ot_txt);
 //$zurl="http://sms.abinfotech.net/api/sendhttp.php?authkey=240201AdTisMa1iO5baf6912&mobiles=7828676884&message=".$text."&sender=bongosikha&route=4&country=91";
 //$zurl="http://sms.abinfotech.net/api/sendhttp.php?authkey=240201AdTisMa1iO5baf6912&mobiles=7828676884,&message=".$text."&sender=bongosikha&route=4&country=0";


$zurl="http://sms.abinfotech.net/api/sendhttp.php?authkey=240201AdTisMa1iO5baf6912&mobiles=8159098899&message=".$text." & new&mobile&sender=bongosikha&route=4";

 $data=file_get_contents($zurl);
print_r($data);

?>