<?php
include"../include/database.php";
$obj=new database();


$days=$_POST['days'];

$rs=$obj->insert_days($days);
if($rs)
{
//	$_SESSION['msg']=" Insert Success Full";
	//header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert Success Full');
          window.location.href='days_list.php';
       </script>");
}
else
{
	//$_SESSION['msg']=" Not Insert";
//	header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Insert');
          window.location.href='days.php';
       </script>");
}
?>