<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$class=$_POST['class'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];


$rs=$obj->updatechapter($class,$subject,$chapter,$id);
if($rs)
{
//	$_SESSION['msg']=" update Success Full";
//	header("location:chapter_list.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='chapter_list';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not update";
//	header("location:chapter_list.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='chapter_list';
       </script>");
}
?>