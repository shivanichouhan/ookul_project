<?php
include"../include/database.php";
$obj=new database();



$subject=$_POST['subject'];





$rs=$obj->insert_exam_subject___007($subject);


if($rs)
{
	$_SESSION['msg']=" Insert SuccessFully";
	header("location:exam_subjects.php");
}
else
{
	$_SESSION['msg']=" Not Insert";
	header("location:exam_subjects.php");
}
?>