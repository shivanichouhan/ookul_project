<?php include"header.php";
include"menu.php";
$b=explode('/',$a);
 $_GET['id']=$b['5']; 

$chapt=$obj->fetchById($_GET['id'],"optional_chapter","id");

$subj=$obj->fetchById($chapt['opt_sub_id'],"optional_subject","id");

 ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Edit  Chapter </h1>
                                <small>Edit Chapter <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="chapter_list">Chapter List</a></li>
                                    <li class="active">Edit Chapter</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Chapter</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form data-toggle="validator" action="<?php echo $base1; ?>edit_chapter_subopt" method="post" enctype="multipart/form-data">
										<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
											<div class="form-group">
                                                <label for="inputName" class="control-label">Subject Name</label>
												<select class="form-control" id="exampleSelect1" name="subject"  >
												 <option value="">--Subject--</option>
												<?php
													$table='optional_subject';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option <?php if($subj['id']==$row['id']) { ?> selected="selected" <?php } ?>  value="<?php echo $row['id']; ?>"><?php echo $row['subject'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Chapter Name</label>
                                                <input type="text" class="form-control" id="chapter" name="chapter" placeholder="Chapter" value="<?php echo $chapt['chapter']; ?>" >
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Image</label>
                                                 <input type="file" class="form-control" id="exampleInputEmail1" name="image" placeholder="image">
												<input type="hidden" class="form-control" name="limg" value="<?php echo $con['image'];?>">
											</div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->
			

       <?php include"footer.php"; ?>