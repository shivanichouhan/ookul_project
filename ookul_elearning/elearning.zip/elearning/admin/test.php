<?php
$mobile=9832462243;
$ot_txt="Welcome your register in bongoshikha.com ";
$text=urlencode($ot_txt);
$zurl="http://sms.abinfotech.net/api/sendhttp.php?authkey=240201AUC8hHhOn5c14a507&mobiles=".$mobile."&message=".$text."&sender=bongosikha&route=4&country=91";
var_dump($zurl);
$data=file_get_contents($zurl);
var_dump($data);
?>
