<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$class=$_POST['class'];
$expiry_date=$_POST['expiry_date'];



$rs=$obj->edit_class($class,$expiry_date,$id);
if($rs)
{
//	$_SESSION['msg']="Update Successfull";
//	header("location:class_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='class_list.php';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Update";
	//header("location:class_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='class_list.php';
       </script>");
}
?>