<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$class=$_POST['class'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];


$rs=$obj->demo_updatechapter($class,$subject,$chapter,$id);
if($rs)
{
//	$_SESSION['msg']=" update Success Full";
//	header("location:demo_chapter_list.php");
	
		 echo ("<script LANGUAGE='JavaScript'>
          window.alert('update Success Full');
          window.location.href='demo_chapter_list';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not update";
//	header("location:demo_chapter_list.php");
echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update');
          window.location.href='demo_chapter_list';
       </script>");
}
?>