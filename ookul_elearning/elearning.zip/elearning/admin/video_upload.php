<?php include"header.php";
include"menu.php";
 ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1> Upload Video Solution </h1>
<small>Upload Video  <a href="#" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="video_solution_list.php"> Video Solution List</a></li>
                                    <li class="active"> Add Video Solution</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
						
						
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Videos</h4>
                                        </div>
                                    </div>
									
<div class="panel-body">
<form method="post" action="add_video_solution_sub"  enctype="multipart/form-data" >
											
											
<div class="form-group">
<label for="inputName" class="control-label">Package </label>
<select class="form-control" id="exampleSelect1" name="package_id" onChange="msubject(this.value)" required>
<option value="">--Package Type--</option>
<?php

$table='package';
$rs=$obj->fetchAllDetail($table);
if($rs)
{	$i=0;
while($row=mysqli_fetch_assoc($rs))
{	$i++;
?>
<option value="<?php echo $row['id']; ?>"><?php echo $row['title'];  ?></option>
<?php } } ?>
</select>

</div>

<div class="form-group">
<label for="inputName" class="control-label">Exam</label>
<select class="form-control" id="sub" name="exam_id" required >
<option value="">--Exam Type--</option>
</select>
</div>
										
<div class="form-group">
<label for="inputName" class="control-label">Title </label></br>
<input class="form-control" type="text" name="title" required />
</div>
								

<div class="form-group">
<label for="inputName" class="control-label">Thumbnail</label></br>
<input type="file" name="image" required />
</div>

<div class="form-group">
<label for="inputName" class="control-label">Video</label></br>
<input type="file" name="video" required />
</div>
											 

<div class="form-group">
<button type="submit" class="btn btn-primary">Submit</button>
</div>
</form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div> 
				</div> 
<script>
function qimage(a){
//alert(a);
$("#mcqimage").load("gove_mcq_image.php?id="+a);
}
</script>

<script>
				 function msubject(a)
				 {
				        var http=new XMLHttpRequest();
						http.onreadystatechange=function()
						{	
						if(http.readyState==4 && http.status==200)
						{
					 	document.getElementById("sub").innerHTML=http.responseText;
						}
						//alert(http.responseText);
						}
						
						http.open("GET","questandansubajax.php?id="+a,true);
						http.send();
				 }
				  </script>
				  

       <?php include"footer.php"; ?>