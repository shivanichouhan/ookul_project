<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");



$coupon=$_POST['coupon'];
$type=$_POST['type'];
$sdate=$_POST['sdate']; 
$edate=$_POST['edate'];
$amount=$_POST['amount'];


$rs=$obj->insert_discount_007_007($coupon,$type,$sdate,$edate,$amount);


if($rs)
{
echo ("<script LANGUAGE='JavaScript'>
window.alert('Coupon Added');
window.location.href='add_discount_coupon_schl';
</script>");
}
else 
{
echo ("<script LANGUAGE='JavaScript'>
window.alert('Not Added');
window.location.href='add_discount_coupon_schl';
</script>");
}
			

?>