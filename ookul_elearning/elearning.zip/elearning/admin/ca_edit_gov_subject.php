<?php include"header.php";
include"menu.php";?>
<?php 

$b=explode('/',$a);
 $_GET['id']=$b['5']; 
$con=$obj->fetchById($_GET['id'],"current_affairs_subject","id"); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="fa fa-graduation-cap"></i>
                            </div>
                            <div class="header-title">
                                <h1>Subject </h1>
                                <small>Edit Subject <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="gov_subject_list.php">Subject List</a></li>
                                    <li class="active">Level</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Subject</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form action="<?php echo $base1; ?>ca_edit_gov_subject_sub" method="post" enctype="multipart/form-data">
										 <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" >
									
										<div class="form-group">
                                                <label for="inputName" class="control-label">Subject  </label>
                                                <input type="text" class="form-control" id="inputName" name="subject_name" placeholder="subject" value="<?php echo $con['subject_name'];?>">
											</div>
											
											<div class="form-group">
                                                <label for="inputName" class="control-label">Image </label>
                                                
                                                 <input type="file" class="form-control" id="exampleInputEmail1" name="image" placeholder="image">
												<input type="hidden" class="form-control" name="limg" value="<?php echo $con['image'];?>">
          
											</div>
										
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary" style="background: -webkit-linear-gradient(left, #ff771c 0%, #ea00ca 50%,#9d09e9 90%);
    border: 1px solid transparent;
    font-weight: 700;">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->

       <?php include"footer.php"; ?>