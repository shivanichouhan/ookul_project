<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");


$exam_name=$_POST['exam_type_id'];
$content=$_POST['content'];
$title=$_POST['title'];
$rs=$obj->insert_school_instructions($exam_name,$content,$title);

if($rs)
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert success');
          window.location.href='school_exam_instruction.php';
       </script>");
       
       
}
else
{
    
    
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not insert');
          window.location.href='school_exam_instruction.php';
       </script>");
}



?>