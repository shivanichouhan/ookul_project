<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");


$id=$_POST['id'];
$topic=$_POST['topic'];


// $path2="gov_upload/";
// $thumbnail=$_FILES['thumbnail']['name']; move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path2.$thumbnail);

$path="gov_upload/";

 if($_FILES['thumbnail']['name']=="") { $thumbnail=$_POST['thumbnaillim']; } else { $thumbnail=$_FILES['thumbnail']['name']; move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path.$thumbnail); }



// $path5="gov_upload/";
//  $video=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path5.$video);

$path5="gov_upload/";

 if($_FILES['video']['name']=="") { $video=$_POST['videolim']; } else { $video=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path5.$video); }


// echo $video;
// die();

$rs=$obj->update_gover_topicfa($subject,$topic,$thumbnail,$video,$id);

if($rs)
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert success');
          window.location.href='fa_video_class_list.php';
       </script>");
}
else
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not insert');
          window.location.href='fa_video_class_list.php';
       </script>");
}



?>