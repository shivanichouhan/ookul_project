<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");


$agent_type=$_POST['agent_type'];
$agent=$_POST['agent'];
$path="upload/";
$img=$_FILES['image']['name']; move_uploaded_file($_FILES['video']['image'],$path.$img);




$rs=$obj->sendpdf($agent_type,$agent,$img);
if($rs)
{
    //$_SESSION['msg']=" Insert  User Success Full";
//	header("location:send_document_pdf.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('PDF Insert Success Full');
          window.location.href='send_document_pdf';
       </script>");
}
else
{
	//$_SESSION['msg']="Insert user  Not Success Full";
	//header("location:send_document_pdf.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('PDF Insert Success Full');
          window.location.href='send_document_pdf';
       </script>");
}
?>