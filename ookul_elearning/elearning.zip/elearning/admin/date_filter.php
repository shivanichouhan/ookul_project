<?php       
include"../include/database.php";
$obj= new database();
$web_info=$obj->fetchByIdTable("website_details");
@$fromDate1=$_GET['fromDate'];
@$endDate1=$_GET['endDate'];

	$fromDate = date("d-m-Y", strtotime($fromDate1));

	$endDate = date("d-m-Y", strtotime($endDate1));
	
	if($fromDate=='')
	{
		$_SESSION['report_date']="0";
	
		header("location:user_payment_conform_list.php");
	}
	else
	{
		if($endDate1=='')
		{	
			$_SESSION['report_date']="1";
	
			header("location:user_payment_conform_list.php?date=$fromDate");
		}
		else
		{
			$_SESSION['report_date']="2";
	
			header("location:user_payment_conform_list.php?date=$fromDate&enddate=$endDate");
		}
	}
	
 ?>