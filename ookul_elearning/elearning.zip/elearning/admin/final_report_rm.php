<?php 
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");
   @$rm_id=$_GET['rm_id'];
 //$block_id=$_GET['block_id'];
  @$sdate=$_GET['sdate'];

  @$edate=$_GET['edate'];

  $originalDate = $sdate;
  $newDate = date("d-m-Y", strtotime($originalDate));
  $originalDate1 = $edate;
  $newDate1 = date("d-m-Y", strtotime($originalDate1));
if($rm_id=='')
{
	header("location:final_RM_report.php?$rm_id");
}	
else
{	
		if($rm_id=='0')
		{
			if($sdate=='')
			{
				 $_SESSION['rm_report']="0"; 
				header("location:final_RM_report.php");
			}
			else
			{
				
			if($edate=='')
				{
					  $_SESSION['rm_report']="1";  
					header("location:final_RM_report.php?sdate=$newDate");
				}
			else
				{
						 $_SESSION['rm_report']="2";  
					header("location:final_RM_report.php?sdate=$newDate&edate=$newDate1");
				}
				
			}
		}
		else
		{
			if($sdate=='')
			{
			 $_SESSION['rm_report']="3"; 
			 
				header("location:final_RM_report.php?id=$rm_id");
			}
			else
			{
				if($edate=='')
				{
					  $_SESSION['rm_report']="4";  
					header("location:final_RM_report.php?id=$rm_id&sdate=$newDate");
				}
				else
				{
					 $_SESSION['rm_report']="5";  
					header("location:final_RM_report.php?id=$rm_id&sdate=$newDate&edate=$newDate1");
				}
			}
		
		}
}	
		

?>