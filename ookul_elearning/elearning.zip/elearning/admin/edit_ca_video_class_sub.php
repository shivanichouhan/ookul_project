<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$subject=$_POST['subject'];
$topic=$_POST['topic'];
$title=$_POST['title'];

$path1="gov_upload/";
//$img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path1.$img);
 if($_FILES['image']['name']=="") { $img=$_POST['limage']; } else { $img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path1.$img); }


$path2="gov_upload/";
//$video=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path2.$video);
 if($_FILES['video']['name']=="") { $video=$_POST['limage11']; } else { $video=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path2.$video); }

$rs=$obj->updateca_video_class($subject,$topic,$img,$video,$title,$id);
if($rs)
{
	

			echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update Success Full');
          window.location.href='ca_video_class_list';
       </script>");
}
else
{
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update Success Full');
          window.location.href='ca_video_class_list';
       </script>");	

}
?>