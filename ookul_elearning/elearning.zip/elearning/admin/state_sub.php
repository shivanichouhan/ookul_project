<?php
include"../include/database.php";
$obj=new database();


$state=$_POST['state'];


$rs=$obj->insertstate($state);
if($rs)
{
	$_SESSION['msg']="State Insert Success Full";
	header("location:state.php");
}
else
{
	$_SESSION['msg']="State Not Insert";
	header("location:state.php");
}
?>