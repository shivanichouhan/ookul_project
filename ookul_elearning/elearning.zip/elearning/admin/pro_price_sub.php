<?php
include"../include/database.php";
$obj=new database();

$class=$_POST['class'];
$type_user=$_POST['type_user'];
$price=$_POST['price'];




$rs=$obj->insertprice_pro($type_user,$price,$class);
if($rs)
{
	//$_SESSION['msg']=" Insert Success Full";
//	header("location:price.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='referal_amount_set';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Insert";
//	header("location:price.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='referal_amount_set';
       </script>");
}
?>