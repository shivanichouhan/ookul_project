
<?php include"header.php";
include"menu.php"; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
			   <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-box1"></i>
                            </div>
                            <div class="header-title">
                                <h1>Block Supervisor Coupan List</h1>
                                <small>List All Coupan's</a></small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="relasedcoupan.php">Block Supervisor Coupan List</a></li>
                                    <li class="active">Block Supervisor Coupan List</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
						
                        <div class="row">
                            <div class="col-sm-12">
							<!--<form data-toggle="validator" action="asign_coupan_pro.php" method="post" enctype="multipart/form-data">-->
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Block Supervisor Asign Coupan List</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                           
											
												<div id="viewc"> 	
											<div class="row" style="margin-bottom:35px;">
                                        <div id="coup1">
										    <div class="col-md-12" > 
										    <div class="col-md-6" >
										 <select class="form-control" onChange="asub(this.value);" name="agent_type">
										<option value="">Assign Type</option>
										<option value="1">Block Supervisor</option>
										<option value="2">PRO</option>	</select>  </div>
										    <div class="col-md-6" > 
                                           </div>
                                        </div>
                                        </div>
	                                   </br></br></br></br>
										<div class="col-md-12" >
										
							
										</div>
										<!--<div class="col-md-6"><input type="text" placeholder="Pro id" class="form-control" name="pro_id" ></div>-->
										<!--<div class="col-md-6"><button type="submit" class="btn btn-primary" style="width: 282px;">Assign</button></div>-->
                                    </div>
                                    	</div>
									
                                </div>
								<!--</form>-->
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
				 <script>
 function asub(a){
				 //alert(a);
				 $("#coup1").load("coupanAjaxass.php?id="+a);
				  }
				  </script>
				  <script>
                     
                        function view(agent,type){
                    
                       // alert(agent);
                        //    alert(type);
                        var http=new XMLHttpRequest();
                        http.onreadystatechange=function()
                        {   
                        if(http.readyState==4 && http.status==200)
                        {
                        document.getElementById("viewc").innerHTML=http.responseText;
                        }
                        //alert(http.responseText);
                        }
                        
                        http.open("GET","viewCoupan.php?agent="+agent+"&type="+type,true);
                        http.send();
                        //estimation(user,bus,date,id);
                        }
                        
                     
                     
                     
                     

                // "viewCoupan.php?id="+a+"&agent="+agent+"
                 // getbook_seats.php?user_id="+user+"&bus="+bus+"&seat="+seat+"&date="+date+"&id="+id,true
                  </script>
				  	 	<script type="text/javascript">
        $('.checked_all').on('change', function() {     
                $('.checkbox').prop('checked', $(this).prop("checked"));              
        });
        //deselect "checked all", if one of the listed checkbox product is unchecked amd select "checked all" if all of the listed checkbox product is checked
        $('.checkbox').change(function(){ //".checkbox" change 
            if($('.checkbox:checked').length == $('.checkbox').length){
                   $('.checked_all').prop('checked',true);
            }else{
                   $('.checked_all').prop('checked',false);
            }
        });
    </script>
				  
        <?php include"footer.php"; ?>
        </div> <!-- ./wrapper -->
        <!-- jQuery -->
        <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->
        <!-- dataTables js -->
        <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
        <script>
            $(document).ready(function () {

                "use strict"; // Start of use strict

                $('#dataTableExample1').DataTable({
                    "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                    "lengthMenu": [[6, 25, 50, -1], [6, 25, 50, "All"]],
                    "iDisplayLength": 6
                });

                $("#dataTableExample2").DataTable({
                    dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    buttons: [
                        {extend: 'copy', className: 'btn-sm'},
                        {extend: 'csv', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'excel', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'print', className: 'btn-sm'}
                    ]
                });

            });
        </script>
    </body>

<!-- Mirrored from thememinister.com/bootstrap-admin-template/template/theme/adminpage_v1.0/dataTables.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 09 Aug 2018 05:44:38 GMT -->
</html>