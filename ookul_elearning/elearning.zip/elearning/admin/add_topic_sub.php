<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");


$class=$_POST['class'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
$topic=$_POST['topic'];
$contant=$_POST['contant'];
$path1="upload/";
$topic_pic=$_FILES['topic_pic']['name']; move_uploaded_file($_FILES['topic_pic']['tmp_name'],$path1.$topic_pic);


$path="upload/";
$img=$_FILES['doucment']['name']; move_uploaded_file($_FILES['doucment']['tmp_name'],$path.$img);


$rs=$obj->insert_topic($class,$subject,$chapter,$topic,$topic_pic,$img,$contant);

if($rs)
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert success');
          window.location.href='add_topic.php';
       </script>");
}
else
{
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not insert');
          window.location.href='add_topic.php';
       </script>");
}



?>