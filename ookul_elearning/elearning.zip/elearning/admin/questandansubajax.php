<?php

include_once("../include/database.php");
$obj= new database();

$id=$_GET['id'];


?>

<option value="">--Exam Name--</option>

		<?php
				
$rs=$obj->fetchDetailById($id,"exam_names","package");
if($rs)
{	//$i=0;
while($row=mysqli_fetch_assoc($rs))
{	//$i++;
?>
<option value="<?php echo $row['id']; ?>"><?php echo $row['category'];  ?></option>
<?php
} 

}
?>





