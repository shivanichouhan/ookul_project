<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$days=$_POST['days'];

$rs=$obj->update_days($days,$id);
if($rs)
{
//	$_SESSION['msg']=" Insert Success Full";
	//header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('update Success Full');
          window.location.href='days_list.php';
       </script>");
}
else
{
	//$_SESSION['msg']=" Not Insert";
//	header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('update Insert');
          window.location.href='days_list.php';
       </script>");
}
?>