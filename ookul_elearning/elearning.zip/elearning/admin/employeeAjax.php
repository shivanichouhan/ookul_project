<?php     
	include"../include/database.php";
	$obj= new database();
	$web_info=$obj->fetchByIdTable("website_details");
	$id=$_GET['id'];
	if($id=='1')
	{
 ?>
 <div class="form-group">
                                                <label for="exampleSelect1">Class</label>
												
                                                <select class="form-control" id="exampleSelect1" name="class"  onChange="clas(this.value);">
												 <option value="">--Class--</option>
												<?php
													$table='class';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['class'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
														
                                            </div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Subject</label>
													<select class="form-control" data-placeholder="Choose a subject..." id="subject" name="subject"  onChange="subj(this.value);">
														 <option value=""> -- Subject --</option>
															</select>
                                               
											</div>	
      
 
<?php } ?>
								
							