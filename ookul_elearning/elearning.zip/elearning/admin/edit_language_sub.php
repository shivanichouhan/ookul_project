<?php
include"../include/database.php";
$obj=new database();


$id=$_POST['id'];
$language=$_POST['language'];


$rs=$obj->update_add_language($language,$id);
if($rs)
{

$_SESSION['msg']=" Update  Success Full";
	header("location:language_list.php");
}
else
{
	$_SESSION['msg']="   Not Update ";
	header("location:language_list.php");
}



?>