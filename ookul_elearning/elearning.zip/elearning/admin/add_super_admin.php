<?php include"header.php";
include"menu.php"; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <div class="content-wrapper">
                <div class="container">
                    <div class="content">
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Employee </h1>
                                <small>Add Employee <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="super_admin_list.php">Employee List</a></li>
                                    <li class="active">Employee </li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Employee</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form  action="add_super_admin_sub.php" enctype="multipart/form-data"  method="post">
                                            <div class="form-group">
                                                <label for="exampleSelect1">Digination</label>
                                                <select class="form-control" name="digination" onChange="emplo(this.value);"  id="city">
                                                 <option value="" disabled >Digination</option>
                                                    <option value="1" >Teacher</option>
                                                    <option value="2">Coupan Manager</option>
                                                     <option value="3">RelationShip Manager Super Admin</option>
                                                </select>
                                            </div>
											<div class="form-group">
												<div id="employee">
												
												</div>
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label"> Name</label>
                                                <input type="text" class="form-control" id="inputName" name="name" placeholder="Super Admin Name " required>
											</div>
											
											<div class="form-group">
                                                <label for="inputName" class="control-label">Email</label>
                                                <input type="email" class="form-control" id="inputName" name="email" placeholder="Email" required>
											</div>
											<div class="form-group">
                                                <label for="inputName" class="control-label">Phone </label>
                                                <input type="text" class="form-control" id="inputName" name="phone" placeholder="phone" required>
											</div>
                                            <div class="form-group">
                                                <label for="inputName" class="control-label">Password </label>
                                                <input type="password" class="form-control" id="inputName" name="password" placeholder="password" required>
                                            </div>
											
                                    		                                      
                                            <div class="form-group">
                                                <label for="inputName" class="control-label">Image  </label>
                                                <input type="file" class="form-control" id="inputName" name="image" placeholder="image" required>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Add Super Admin</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> 
			
	
       <?php include"footer.php"; ?>
	    <script>
 function clas(a){
                 //alert(a);
                 $("#subject").load("subjectAjax.php?id="+a);
                  }
                  </script>
<script>
		function emplo(b){
					    //alert(b);
						
						var http=new XMLHttpRequest();
						http.onreadystatechange=function()
						{	
						if(http.readyState==4 && http.status==200)
						{
					 	document.getElementById("employee").innerHTML=http.responseText;
						}
						//alert(http.responseText);
						}
						
						http.open("GET","http://app.bongosikha.com/admin/employeeAjax.php?id="+b,true);
						http.send();
						//estimation(user,bus,date,id);
						}
						

				  </script>