<?php
include"../include/database.php";
$obj=new database();

$web=$obj->fetchByIdTable("website_details");


$title=$_POST['title'];
$contant=$_POST['contant'];

$path='upload/';


$img=$_FILES['file_name']['name'];
 $countfiles = count($_FILES['file_name']['name']);
$array=array();
 for($i=0;$i<$countfiles;$i++){
    
   $filename = $_FILES['file_name']['name'][$i];
  // $uniq=uniqid().$filename
  //$y= explode("@", $filename);
array_push($array,$filename);
   // Upload file
   move_uploaded_file($_FILES['file_name']['tmp_name'][$i],$path.$filename);
    
 }
 $imp=implode(",",$img);
  $imp;
$rs=$obj->insert_search($title,$contant,$imp);
  
if($rs)
{
	 
	
	
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert Successfully');
          window.location.href='search';
       </script>");
}
else
{ 

 	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Failed.............');
          window.location.href='search';
       </script>");

}
?>