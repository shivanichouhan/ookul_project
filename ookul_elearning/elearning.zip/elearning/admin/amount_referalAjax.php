<?php       include"../include/database.php";


$obj= new database();
$web_info=$obj->fetchByIdTable("website_details");
 ?> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4> User List</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                    <tr>
														<th>Name</th>
														<th>Email</th>
														<th>Mobile Number</th>
														<th>Amount</th>
														<th>District</th>
														
														<th>Address</th>
											
												<!--<th>Adhar Card Number</th>-->
												
														<th>Profile</th>
														<th>Document</th>
														<th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
												
 <?php
 

// $_GET['amount'];

   $row=$obj->fetchDetailById($_GET['amount'],"referal_agent","id");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){
	 // $cit=$obj->fetchById($rs['district'],"city","id");
	
												?>
                                                   <td><?php echo $rs['username']; ?></td>
													<td><?php echo $rs['email']; ?></td>
													<td><?php echo $rs['mobile']; ?></td>
													<td><?php echo $rs['amount'];  ?></td>
                          <td><?php 

            $u=explode(",",$rs['district']);
            foreach($u as $uu =>$value)
            {
            //echo $u;
              $user=$obj->fetchById($u[$uu],"city","id");
                 echo $user['city'] ; 
            echo ",";
            }?>       


</td>
													
													<td><?php echo $rs['address']; ?></td>
												
																<!--	<td><?php echo $rs['adhar_no'];  ?></td>-->
													<td><a href="upload/<?php echo $rs['image']; ?>"><img src="upload/<?php echo $rs['image']; ?>" style="width: 50px; height: 50px;"></a>
														<a href="upload/<?php echo $rs['document']; ?>" download>Download</a></td>
    	<td><a href="upload/<?php echo $rs['document']; ?>" download><i class="fa fa-download" aria-hidden="true"></i></a></td>
														<td>
														<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="edit_agent.php?id=<?php echo $rs['id'];?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a></li>
    <li><a href="delete.php?id=<?php echo $rs['id'];?>&table=referal_agent&field=id&page=referal_angent_list" onClick="return confirm('Are you sure?');"><i class="fa fa-trash" aria-hidden="true"></i>Delete</a></li>
   <?php if($rs['status']==1){?>
   <li><a href="updateStatus.php?id=<?php echo $rs['id'];?>&status=0&table=referal_agent&statusField=status&field=id&page=referal_angent_list">Deactive</a></li><?php } ?>
	 <?php if($rs['status']==0){?><li><a href="updateStatus.php?id=<?php echo $rs['id'];?>&status=1&table=referal_agent&statusField=status&field=id&page=referal_angent_list" >Active</a></li><?php } ?>
  
     </ul>
</div></td>
                                                    </tr>
															<?php 
														}
													} ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
        