<?php include"header.php";
include"menu.php"; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-box1"></i>
                            </div>
                            <div class="header-title">
                                 <h1>PRO Report</h1>
                                <small>PRO Report Weekly,Monthly,Yearly</a></small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="add_agent.php"></a></li>
                                    <li class="active">PRO Report List</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>PRO List</h4>
                                        </div>
                                    </div>
																	


   <!-- CSS -->
   <link href='jquery-ui.min.css' rel='stylesheet' type='text/css'>

   <!-- Script -->
   <script src='jquery-3.3.1.js' type='text/javascript'></script>
   <script src='jquery-ui.min.js' type='text/javascript'></script>
   <script type='text/javascript'>
   $(document).ready(function(){
     $('.dateFilter').datepicker({
        dateFormat: "yy-mm-dd"
     });
   });
   </script>

   <div class="panel-body">
	   <div class="col-md-12">
	      <div class="col-md-4">
             <select class="form-control" id="exampleSelect1" name="class"  onChange="clas(this.value);" >
												 <option value="">District</option>
												<?php
													$table='city';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['city'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
												</div>
											<!--	<div class="col-md-2">
												 <select class="form-control" id="exampleSelect1" name="class"  onChange="block(this.value);">
												 <option value="">Block</option>
												<?php
													$table='block';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['block'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
												</div>-->
												   <div class="col-md-4">
												 <select class="form-control" id="exampleSelect1" name="class"  onChange="block(this.value);">
												 <option value="">Block | Name</option>
												<?php
													$table='block';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
                                                                $blk=$obj->fetchById($row['id'],"subagent","block_id");
															?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['block'];  ?> | <?php echo $blk['name']; ?></option>
													<?php } 
													}
													?>
                                                </select>
												</div>
											<!--	<div class="col-md-4">
             <select class="form-control" id="exampleSelect1" name="amount"  onChange="amo(this.value);" >
												 <option value="">Amount</option>
												<?php
													$table='subagent';
													$rs=$obj->fetchAllDetailByStatus($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['amount'];  ?></option>
													<?php } 
													}
													?>
                                                </select>
												</div>-->
   <!---<form method='post' action=''>
    <div class="col-md-2">
    <input type='text' class='form-control' placeholder='Start Date' name='fromDate' value='<?php if(isset($_POST['fromDate'])) echo $_POST['fromDate']; ?>'>
	 </div>
	  <div class="col-md-2">
 
    <input type='text' class='form-control' name='endDate' placeholder='End Date' value='<?php if(isset($_POST['endDate'])) echo $_POST['endDate']; ?>'>
</div>
 <div class="col-md-1">
     <input type='submit' name='but_search' value='Search'  class="form-control btn btn-success">
	 </div>
   </form>-->
   </div>
   <div id="subagent" >
            </div>
			<!--<div id="block"></div>-->
			<!--<div id="agent">
            </div>-->
		<!--	<div id="amount">
            </div>-->
			<div id="block">
            </div>
</div>

   <!-- Employees List -->
 
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                    <tr>
													<th>#</th>
														<th>Block Supervisor Name</th>
														<th>Email</th>
														<th>Mobile Number</th>
														<!--<th>Amount</th>-->
														<th>Reffered District</th>
														<th>Reffered Block</th>
														<th>Address</th>
												        <th>Adhar Card Number</th>
												        <th>Account Holder Name </th>
														<th>Account Number </th>
														<th>ifc code </th>
														<th>Branch Name </th>
														<th>Profile</th>
														<th>Upload document</th>
														<th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
												 <?php
        $row=$obj->fetchAllDetail("pro_register");
  if($row){
	  $i=0;
  while($rs=mysqli_fetch_assoc($row)){
	  $i++;
	  	//  $agent=$obj->fetchById($rs['agent_id'],"agent","id");
	  $cit=$obj->fetchById($rs['city_id'],"city","id");
	  $block=$obj->fetchById($rs['block_id'],"block","id");


?>

                                                    <tr>
													<td><?php echo $i; ?></td>
												
													<td><?php echo $rs['name']; ?></td>
													<td><?php echo $rs['email']; ?></td>
													<td><?php echo $rs['mobile']; ?></td>
													<!--<td><?php echo $rs['amount']; ?></td>-->
													
													
                                                        <td><?php echo $cit['city']; ?></td>
														<td><?php echo $block['block']; ?></td>
													
													<td><?php echo $rs['address']; ?></td>
												
													<td><?php echo $rs['adhar_no'];  ?></td>
														<td><?php echo $rs['account_holder_name']; ?></td>
														<td><?php echo $rs['account_number']; ?></td>
														<td><?php echo $rs['ifc_code']; ?></td>
														<td><?php echo $rs['branch_name']; ?></td>
																		<td><a href="upload/<?php echo $rs['photo']; ?>"><img src="upload/<?php echo $rs['photo']; ?>" style="width: 50px; height: 50px;"></a>
														</td>
    	 <td><a href="upload/<?php echo $rs['document']; ?>"><i class="fa fa-download" aria-hidden="true" style="font-size: 50px;   color: #f74d59; "></i></a></td>
                                                  		
												  <td><a href="pro_panel_report.php?id=<?php echo $rs['id']; ?>"><button type="button" class="btn btn-danger" style="background-color: #ac08e4;
    border-color: #ac08e4;"> View</button></a></td>
                                                    </tr>
														                                                 <?php      }
        }else{
          echo "<tr>";
          echo "<td colspan='4'>No record found.</td>";
          echo "</tr>";
        }
        ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
			   <script>
 function block(a){
				 //alert(a);
				 $("#block").load("block_Ajax_filter.php?id="+a);
				  }
				  </script>
					    <script>
 function clas(a){
				 //alert(a);
				 $("#subagent").load("user_subagent_Ajax.php?id="+a);
				  }
				  </script>
				  		   
				  <script>
 function amo(a){
			//	 alert(a);
				 $("#amount").load("amount_detail.php?id="+a);
				  }
				  </script>
				  
        <?php include"footer.php"; ?>
        </div> <!-- ./wrapper -->
        <!-- jQuery -->
        <script data-cfasync="false" src="../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->
        <!-- dataTables js -->
        <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
        <script>
            $(document).ready(function () {

                "use strict"; // Start of use strict

                $('#dataTableExample1').DataTable({
                    "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                    "lengthMenu": [[6, 25, 50, -1], [6, 25, 50, "All"]],
                    "iDisplayLength": 6
                });

                $("#dataTableExample2").DataTable({
                    dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    buttons: [
                        {extend: 'copy', className: 'btn-sm'},
                        {extend: 'csv', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'excel', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'print', className: 'btn-sm'}
                    ]
                });

            });
        </script>
    </body>

<!-- Mirrored from thememinister.com/bootstrap-admin-template/template/theme/adminpage_v1.0/dataTables.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 09 Aug 2018 05:44:38 GMT -->
</html>