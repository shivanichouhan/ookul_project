<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$subject=addslashes($_POST['subject']);
$topic=addslashes($_POST['topic']);

// $path1="gov_upload/";
// $img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path1.$img);

$rs=$obj->update_current_affairs_topic($subject,$topic,$id);
if($rs)
{
	
	
	
	  	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update Success');
          window.location.href='ca_topic_list';
       </script>");
}
else
{
	
	
	  	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update Success');
          window.location.href='ca_topic_list';
       </script>");
}
?>