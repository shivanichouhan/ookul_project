<?php
include"../include/database.php";
$obj=new database();


$class=$_POST['class'];
$expiry_date=$_POST['expiry_date'];

$rs=$obj->insertclass($class,$expiry_date);
if($rs)
{
//	$_SESSION['msg']=" Insert Success Full";
	//header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='class_list.php';
       </script>");
}
else
{
	//$_SESSION['msg']=" Not Insert";
//	header("location:add_class.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='class_list.php';
       </script>");
}
?>