<?php include"header.php";
include"menu.php";
$op=$obj->fetchById($_GET['id'],"gove_class","id");
 $sub=$obj->fetchById($op['day'],"days","id");
 $pla=$obj->fetchById($op['plan'],"gov_plan","id");
 
 ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="fa fa-table"></i>
                            </div>
                            <div class="header-title">
                                <h1>Level </h1>
                                <small>Add Level <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="gove_class_list.php">Goverment Level List</a></li>
                                    <li class="active">Level</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Level</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form data-toggle="validator" action="edit_gove_class_sub.php" method="post">
                                            <div class="form-group">
                                                <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
										
                                                <label for="inputName" class="control-label">Plan  </label>
                                                <select class="form-control" data-placeholder="month"  name="month">
														 <option value=""> -- Plan --</option>
															<?php
													$table='gov_plan';
													$rs=$obj->fetchAllDetail($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                     <option <?php if($op['plan']==$row['id'])  { ?> selected="selected"  <?php } ?> value="<?php echo $row['id']; ?>"><?php echo $row['plan_name'];  ?></option>
												<?php } 
													}
													?>
                                                </select>
													
                                          	</div>
                                          	<div class="form-group">
                                                <label for="inputName" class="control-label">Days  </label>
                                                <select class="form-control" data-placeholder="month"  name="month">
														 <option value=""> -- Days --</option>
															<?php
													$table='days';
													$rs=$obj->fetchAllDetail($table);
													if($rs)
													{	$i=0;
														while($row=mysqli_fetch_assoc($rs))
														{	$i++;
      
															?>
                                                     <option <?php if($op['day']==$row['id'])  { ?> selected="selected"  <?php } ?> value="<?php echo $row['id']; ?>"><?php echo $row['days'];  ?></option>
												<?php } 
													}
													?>
                                                </select>
													
                                          	</div>
											<div class="form-group">
											
                                                <label for="inputName" class="control-label">Level Name</label>
                                                <input type="text" class="form-control" id="inputName" name="level" placeholder="class"  value="<?php echo $op['level'];?>">
											</div>
											
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary" style="    background: -webkit-linear-gradient(left, #ff771c 0%, #ea00ca 50%,#9d09e9 90%);
    border: 1px solid transparent;
    font-weight: 700;">Add Class</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->



       <?php include"footer.php"; ?>