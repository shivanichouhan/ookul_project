<?php
include"../include/database.php";
$obj=new database();




$class_id=$_POST['class_id'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
$topic=$_POST['topic'];
$type=$_POST['type'];

 $question=$_POST['question'];
 $option1=$_POST['option1'];
 $option2=$_POST['option2'];
 $option3=$_POST['option3'];
 $option4=$_POST['option4'];
 $answer=$_POST['answer'];
 
 $path1="upload/";
$question_image=$_FILES['question_image']['name']; move_uploaded_file($_FILES['question_image']['tmp_name'],$path1.$question_image);

$path2="upload/";
$option_img1=$_FILES['option_img1']['name']; move_uploaded_file($_FILES['option_img1']['tmp_name'],$path2.$option_img1);

$path3="upload/";
$option_img12=$_FILES['option_img12']['name']; move_uploaded_file($_FILES['option_img12']['tmp_name'],$path3.$option_img12);

$path4="upload/";
$option_img3=$_FILES['option_img3']['name']; move_uploaded_file($_FILES['option_img3']['tmp_name'],$path4.$option_img3);

$path5="upload/";
$option_img4=$_FILES['option_img4']['name']; move_uploaded_file($_FILES['option_img4']['tmp_name'],$path5.$option_img4);


$rs=$obj->question($class_id,$subject,$chapter,$topic,$type,$question,$option1,$option2,$option3,$option4,$question_image,$option_img1,$option_img12,$option_img3,$option_img4,$answer);
if($rs)
{
	//$_SESSION['msg']=" Insert Success Full";
//	header("location:mlutipal_question_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='multipal_question.php';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Insert";
//	header("location:mlutipal_question_list.php");
echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='multipal_question.php';
       </script>");
}
?>