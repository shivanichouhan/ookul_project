<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

$id=$_POST['id'];
  $heading=$_POST['heading'];
  $app_type=$_POST['app_type'];

$path="gov_upload/";

 if($_FILES['thumbnai']['name']=="") { $thumbnail1=$_POST['limg']; } else { $thumbnail1=$_FILES['thumbnai']['name']; move_uploaded_file($_FILES['thumbnai']['tmp_name'],$path.$thumbnail1); }


$path="gov_upload/";

 if($_FILES['video']['name']=="") { $vedio1=$_POST['limg1']; } else { $vedio1=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path.$vedio1); }



//  $path="gov_upload/";
// $vedio1=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path.$vedio1);
//  $path1="gov_upload/";
// $thumbnail1=$_FILES['thumbnai']['name']; move_uploaded_file($_FILES['thumbnai']['tmp_name'],$path1.$thumbnail1);


$rs=$obj->edit_goverment_popular_video($heading,$thumbnail1,$vedio1,$app_type,$id);
if($rs)
{
	
//	$_SESSION['msg']=" Insert  User Success Full";
//	header("location:papular_video.php");
		 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update   Success Full');
          window.location.href='govermnt_popular_video.php';
       </script>");
}
else
{
		 echo ("<script LANGUAGE='JavaScript'>
          window.alert('not update');
          window.location.href='govermnt_popular_video.php';
       </script>");
}