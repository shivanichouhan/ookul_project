<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];

$name_year=$_POST['name_year'];


$start_year=$_POST['start_year'];
$end_date=$_POST['end_date'];
$class=$_POST['class'];
$rs=$obj->updateacadmic($name_year,$start_year,$end_date,$class,$id);
if($rs)
{
	
//	$_SESSION['msg']="Update Successfull";
//	header("location:academy_list.php");
	
		 echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='academy_list';
       </script>");
}
else
{
	
	//$_SESSION['msg']=" Not Update";
//	header("location:academy_list.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update');
          window.location.href='academy_list';
       </script>");
}
?>