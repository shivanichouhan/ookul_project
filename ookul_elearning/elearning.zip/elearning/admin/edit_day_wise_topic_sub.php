<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$days=$_POST['days'];
$subject=$_POST['subject'];
$topic=$_POST['topic'];


$check=$obj->fetchById($subject,"assign_subject","id");

$mainsubject=$check['subject'];



$rs=$obj->Update_topic_daywise0000($days,$subject,$topic,$id,$mainsubject);

if($rs)
{
    	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Update Successfully');
          window.location.href='day_wise_topic';
       </script>");
}
else
{
    	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Update Succesfully');
          window.location.href='day_wise_topic';
       </script>");
}
?>