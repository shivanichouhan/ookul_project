 <option value=""> -- select --</option>
 <?php
include"../include/database.php";
$obj= new database();


if($_GET['id']==1)
{
   $row=$obj->fetchAllDetailByStatus("agent");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?> | <?php echo $rs['email'];?></option>
   <?php }}?>
<?php }

elseif($_GET['id']==2)
{
	   $row=$obj->fetchAllDetailByStatus("subagent");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?> | <?php echo $rs['email'];?></option>
   <?php }}?>
	<?php
}
elseif($_GET['id']==3)
{
	  $row=$obj->fetchAllDetailByStatus("referal_agent");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>"><?php echo $rs['username'];?> | <?php echo $rs['email'];?></option>
   <?php }}
} elseif($_GET['id']==4)
{
	  $row=$obj->fetchAllDetailByStatus("pro_register");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?> | <?php echo $rs['pro_id'];?></option>
   <?php }}
} else {
	echo"No Ageent's Select";
	
 } ?>