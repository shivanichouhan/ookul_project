<?php
include"../include/database.php";
$obj=new database();

$class=$_POST['class'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];


$rs=$obj->insertchapter($class,$subject,$chapter);
if($rs)
{
//	$_SESSION['msg']=" Insert Success Full";
//	header("location:chapter.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='chapter';
       </script>");

}
else
{
//	$_SESSION['msg']=" Not Insert";
//	header("location:chapter.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='chapter';
       </script>");

}
?>