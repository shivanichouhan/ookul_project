<?php
include"../include/database.php";
$obj=new database();

    
  if(@$_GET['id']=='1')
  {
   ?>
           <link href="https://app.bongosikha.com/admin/assets/plugins/summernote/summernote.css" rel="stylesheet" type="text/css"/>


      <?php }elseif(@$_GET['id']=='2')
	  { ?>
	  
		  








	  <?php }	else {
		  
	  }  ?>
	          