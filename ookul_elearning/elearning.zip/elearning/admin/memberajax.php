  <option value="all">----Select All----</option>
  
 <?php

include_once("../include/database.php");
$obj= new database();

if($_GET['id']==1)
{
	
  $row=$obj->fetchDetailByIdMember(1,"agent","status");
  if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>"><?php echo $rs['name'];?></option>
   <?php }}
}
else if($_GET['id']==2){
		
	$row=$obj->fetchDetailByIdMember(1,"class","status");
if($row){
  while($rs=mysqli_fetch_assoc($row)){?>
    <option value="<?php echo $rs['id'];?>"><?php echo $rs['class'];?></option>
   <?php }}
}
 ?>