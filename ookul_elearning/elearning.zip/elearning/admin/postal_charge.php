<?php include"header.php";
include"menu.php"; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                               <i class="fa fa-inr" aria-hidden="true"></i>
                            </div>
                            <div class="header-title">
                                <h1>Delivery Charges </h1>
                                <small>Add Delivery Charges <a href="https://1000hz.github.io/bootstrap-validator/" target="_blank"></a> </small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="delivery_charges_list">Delivery Charges List</a></li>
                                    <li class="active">Delivery Charges</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Delivery Charges</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form data-toggle="validator" action="add_charges" method="post">
										
											<div class="form-group">
                                                <label for="inputName" class="control-label">Postal Code</label>
                                                <input type="text" class="form-control" id="inputName" name="potal_code" placeholder="postal code" required>
											</div>
												<div class="form-group">
                                                <label for="inputName" class="control-label">Delivery Charges</label>
                                                <input type="text" class="form-control" id="inputName" name="delivery_charges" placeholder="Delivery Charges" required>
											</div>
											
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary" style="    background: -webkit-linear-gradient(left, #ff771c 0%, #ea00ca 50%,#9d09e9 90%);
    border: 1px solid transparent;
    font-weight: 700;">Add Charges</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.
			-wrapper -->
            <!-- start footer -->



       <?php include"footer.php"; ?>