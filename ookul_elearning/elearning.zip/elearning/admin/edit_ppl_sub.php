<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];
$heading=$_POST['heading'];


$path2="upload/";
 if($_FILES['thumbnail']['name']=="") { $thumbnail=$_POST['limg1']; } else { $thumbnail=$_FILES['thumbnail']['name']; move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path2.$thumbnail); }


$path="upload/";
 if($_FILES['video']['name']=="") { $video=$_POST['limg']; } else { $video=$_FILES['video']['name']; move_uploaded_file($_FILES['video']['tmp_name'],$path.$video); }


$rs=$obj->edit_updatevideo($heading,$thumbnail,$video,$id);
if($rs)
{
//	$_SESSION['msg']="Insert Success";
//	header("location:ppl.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('Insert Success');
          window.location.href='ppl';
       </script>");
}
else
{
echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not success');
          window.location.href='ppl';
       </script>");
}
?>