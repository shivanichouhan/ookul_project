<?php
include"../include/database.php";
$obj=new database();

$id=$_POST['id'];

$name=$_POST['name'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$digination=$_POST['digination'];
@$class=$_POST['class'];
@$subject=$_POST['subject'];

$password=$_POST['password'];
$path="../admin/upload/";
 if($_FILES['image']['name']=="") { $img=$_POST['limg']; } else { $img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path.$img); }



$rs=$obj->update_super_admin($name,$email,$phone,$password,$digination,$class,$subject,$img,$id);
if($rs)
{
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='super_admin_list';
       </script>");
}
else
{
    echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='super_admin_list';
       </script>");
}
?>