<?php
include"../include/database.php";
$obj=new database();
$web=$obj->fetchByIdTable("`website_details`");

$id=$_POST['id'];
$category=$_POST['category'];
 $product=$_POST['product'];
$price=$_POST['price'];
 $discount_type=$_POST['discount_type'];
$discount_amount=$_POST['discount_amount'];

$contant=$_POST['contant'];

$path="upload/";
 if($_FILES['image']['name']=="") { $img=$_POST['limg']; } else { $img=$_FILES['image']['name']; move_uploaded_file($_FILES['image']['tmp_name'],$path.$img); }

$rs=$obj->update_product($category,$product,$img,$price,$discount_type,$discount_amount,$contant,$id);

if($rs)
{
	
//	$_SESSION['msg']=" Update Success Full";
//	header("location:product_list.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='product_list';
       </script>");
}
else
{
//	$_SESSION['msg']="Update Not Success Full";
//	header("location:product_list.php");
	echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='product_list';
       </script>");
}


?>
