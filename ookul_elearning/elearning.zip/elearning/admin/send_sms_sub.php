<?php
include"../include/database.php";
$obj=new database();
$phone=$_POST['phone'];
$message=$_POST['message'];
 $user_id=$_SESSION['user_id'];
    

$rs=$obj->send_sms_user($user_id,$message,$phone);

if($rs)
{

  $ot_txt=$message;
$text=urlencode($ot_txt);
 $zurl="http://sms.abinfotech.net/api/sendhttp.php?authkey=227665Adf9OKeld5b55bac7&mobiles=".$phone."&message=".$text."&sender=getpay&route=4&country=91";
 
 $data=file_get_contents($zurl);


header("location:contact_emailer.php");
}
else
{ 
header("location:contact_emailer.php");
}

?>
