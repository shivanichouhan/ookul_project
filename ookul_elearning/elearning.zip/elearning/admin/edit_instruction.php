<?php include"header.php";
include"menu.php"; ?>
<?php $b=explode('/',$a);
 $_GET['id']=$b['5']; ?>

<!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <i class="pe-7s-note2"></i>
                            </div>
                            <div class="header-title">
                                <h1>Instruction </h1>
                                <small>Edit Instruction</small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="front_video_list">Instruction List</a></li>
                                    <li class="active">Edit Instruction  Video</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
						<?php $con=$obj->fetchById($_GET['id'],"instruction","id"); ?>
                        <div class="row">
                            <div class="col-sm-12">
							<form data-toggle="validator" action="<?php echo $base1; ?>edit_instrection_sub" method="post" enctype="multipart/form-data">
                        
                                <div class="panel panel-bd lobidrag">
									
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Instruction </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
									<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" >
                                                    <div class="form-group">
									<label for="inputName" class="control-label">App Type</label>
										<select class="form-control" name="app_type">
										    <option>App Type</option>
										      <option <?php if($con['app_type']=='1') { ?> selected="selected" <?php } ?> value="1">Bongoshikha </option>
										       <option <?php if($con['app_type']=='2') { ?> selected="selected" <?php } ?> value="2">E-Goverment Free Access</option>
										</select>
									</div> 
									<div class="form-group">
									<label for="inputName" class="control-label">Image</label>
										<input type="file" class="form-control" id="exampleInputEmail1" name="image" placeholder="video">
												<input type="hidden" class="form-control" name="limg" value="<?php echo $con['image'];?>">
									</div>
									<div class="form-group">
										<label for="inputName" class="control-label">Contant</label>
										<textarea id="summernote" name="contant"><?php echo $con['contant']; ?></textarea>
										</div>
										<div class="form-group">
										<button type="submit" class="btn btn-primary">Update Instruction</button>
										</div>
                                    </div>
                                </div>
								</form>
                            </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
       <?php include"footer.php"; ?>]