<?php
include"../include/database.php";
$obj=new database();




$class_id=$_POST['class_id'];
$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
 $question=$_POST['question'];

  $option1=$_POST['option1'];
 $option2=$_POST['option2'];
 $option3=$_POST['option3'];
 $option4=$_POST['option4'];
 $answer=$_POST['answer'];


$rs=$obj->demoquestion($class_id,$subject,$chapter,$question,$option1,$option2,$option3,$option4,$answer);
if($rs)
{
//	$_SESSION['msg']=" Insert Success Full";
//	header("location:demo_mcq_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_mcq_list';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Insert";
//	header("location:demo_mcq_list.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_mcq_list';
       </script>");
}
?>