<?php
include"../include/database.php";
$obj=new database();



$subject=$_POST['subject'];
$topic=$_POST['topic'];


$filename=$_FILES["file"]["tmp_name"];	


		 if($_FILES["file"]["size"] > 0)
		 {
	
		  	$file = fopen($filename, "r");
	        while (($data = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
                		 {  
                $aa=$obj->goverment_assigmentbulk($subject,$topic,addslashes($data[0]),addslashes($data[1]),addslashes($data[2]),addslashes($data[3]),addslashes($data[4]),addslashes($data[5]),$data[6]);
                
                }
	         }
	         
	         //$us=$obj->updateexamsub($aa,$exam_type_id,$subject);
	          echo ("<script LANGUAGE='JavaScript'>
          window.alert('Uploaded');
          window.location.href='ca_assigement_list';
       </script>");
		 }
		 else {
		     
		     	 echo ("<script LANGUAGE='JavaScript'>
          window.alert('Not Upload');
          window.location.href='ca_assigement_list';
       </script>");

		 }
		 
		 ?>