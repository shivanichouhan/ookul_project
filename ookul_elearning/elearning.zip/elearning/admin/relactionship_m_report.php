<?php include"header.php";
include"menu.php"; 
$iii=$obj->fetchById($_GET['id'],"referal_agent","id");
?>
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                               <i class="fa fa-file" aria-hidden="true"></i>
                            </div>
                            <div class="header-title">
                                <h1> Relactionship Manager -  Report ( <?php echo $iii['username'];  ?> )</h1>
                                <small>View detailed & featured admin.</small>
                                <ol class="breadcrumb">
                                    <li><a href="deshabord"><i class="pe-7s-home"></i> Home</a></li>
                                    <li class="active">Executive Supervisor Report</li>
                                </ol>
                            </div>
                        </div>  <!-- /.Content Header (Page header) -->
                        <div class="row">
						<div class="header-title">
                                <h1 style="text-align: center;"> Total Report</h1>
								</div>
                            <div class="col-xs-4">
                                <!-- statistic box -->
                                <div class="statistic-box statistic-filled-1">
                                    <h2><span class="count-number"><?php 
	
$total=0;
$amountclass;
$executive_id=$iii['executive_id'];
 $u=explode(",",$executive_id);
foreach($u as $uu =>$value)
	{
		$aa=$obj->fetchById($u[$uu],"agent","id");
	 	  $id=$aa['id'];

	$rsu=$obj->fetchDetailById(1,"user_register","pstatus");
					//print_r($rsu);
					//echo "</br>";
					if($rsu)
					{	
						while($row21=mysqli_fetch_assoc($rsu))
						{	$i++;
    						if($row21['pro_id']=='')
    						{}
    						else
    						{
    						    $class=$row21['class'];
    						    $amo=$obj->fetchByIdByStatus($class,"markting_price","class","type_user",1);
    						   $amountclass= $amo['price'];
        							 $pro = $row21['pro_id'];
        						$aa1=$obj->fetchById($pro,"pro_register","pro_id");
        				
        						 	$refferal_agent_id=$aa1['refferal_agent_id'];
        						if($refferal_agent_id=='')
        						{}
        						else
        						{
        						    
        					
            						if($id==$refferal_agent_id)	
            						{
            						     $row21['id'];
            						    
            						    $total=$total+1;
            						}
        						}
    						}   
						}
					}


}
 $total;
 $amountclass;
//--------------------gov---------------
$total1=0;
$amountclass1;
$executive_id=$iii['executive_id'];
 $u=explode(",",$executive_id);
foreach($u as $uu =>$value)
	{
		$aa=$obj->fetchById($u[$uu],"agent","id");
	 	  $id=$aa['id'];

	$rsu=$obj->fetchDetailById(1,"user_register_goverment","pstatus");
					//print_r($rsu);
					//echo "</br>";
					if($rsu)
					{	
						while($row21=mysqli_fetch_assoc($rsu))
						{	$i++;
    						if($row21['pro_id']=='')
    						{}
    						else
    						{
    						   
    						    
        							 $pro = $row21['pro_id'];
        						$aa1=$obj->fetchById($pro,"pro_register","pro_id");
        				
        						 	$refferal_agent_id=$aa1['refferal_agent_id'];
        						if($refferal_agent_id=='')
        						{}
        						else
        						{
        						    
        					
            						if($id==$refferal_agent_id)	
            						{
            						     $row21['id'];
            						    
            						    $total1=$total1+1;
            						}
        						}
    						}   
						}
					}


}
echo $total+$total1;

 ?> </span> <span class="slight"><!--<i class="fa fa-play fa-rotate-270 text-warning"> </i> +28%</span>--></h2>
                                    <div class="small">Total User</div>
                                   <i class="hvr-buzz-out pe-7s-add-user" style="font-size: 50px; position: absolute;right: 30px; top: 16px;"></i>
								  
                                  <!--  <div class="sparkline1 text-center"></div>-->
                                </div> <!-- /. statistic box -->
                            </div>
                            <div class="col-xs-4">
                                <!-- statistic box -->
                                <div class="statistic-box statistic-filled-2">
                                    <h2><span class="count-number"><?php 
                                 
                                      $amo1=$obj->fetchByIdByStatus(0,"markting_price","class","type_user",1);
    						   $amountclass1= $amo1['price'];
                                   $a= $total1*$amountclass1;
                                   $b= $total* $amountclass;
                                   echo $a+$b;
                                            ?></span> <span class="slight"><!--<i class="fa fa-play fa-rotate-90 c-white"> </i> +10%</span>--> </h2>
                                    <div class="small">Total Amount</div>
                                   <i class="fa fa-inr" style="font-size: 50px; position: absolute;right: 30px; top: 16px;"></i>
                                    <!--<div class="sparkline2 text-center"></div>-->
                                </div>  <!-- /.statistic box -->
                            </div>
                            
                            
                        </div>
						<!----------This Month---------------------->
                        <div class="row">
						<div class="header-title">
                                <h1 style="text-align: center;"> This Month Report</h1>
								</div>
                            <div class="col-xs-4"  >
                                <!-- statistic box -->
                                <div class="statistic-box statistic-filled-1" style="    background-color: #352c2c;
    border-color: #352c2c;
    color: #fff;">
                                    <h2><span class="count-number"><?php   
 $totalm=0;
$amountclassm;
$executive_id=$iii['executive_id'];
 $u=explode(",",$executive_id);
foreach($u as $uu =>$value)
	{
		$aa=$obj->fetchById($u[$uu],"agent","id");
	 	  $id=$aa['id'];

	$rsu=$obj->fetchDetailById(1,"user_register","pstatus");
					//print_r($rsu);
					//echo "</br>";
					if($rsu)
					{	
						while($row21=mysqli_fetch_assoc($rsu))
						{	$i++;
    						if($row21['pro_id']=='')
    						{}
    						else
    						{
    						    $class=$row21['class'];
    						    $amo=$obj->fetchByIdByStatus($class,"markting_price","class","type_user",1);
    						   $amountclassm= $amo['price'];
        							 $pro = $row21['pro_id'];
        						$aa1=$obj->fetchById($pro,"pro_register","pro_id");
        				
        						 	$refferal_agent_id=$aa1['refferal_agent_id'];
        						if($refferal_agent_id=='')
        						{}
        						else
        						{
        						    
        					
            						if($id==$refferal_agent_id)	
            						{
            						    $payment_s=$row21['payment_success_date'];
									$dd1=explode("-",$payment_s);
									 $yy2=$dd1['1'];
									$date=date("Y-m-d");
									$dd=explode("-",$date);
									 $yy1=$dd['1'];
    									if($yy2==$yy1)
    									{
                						     $row21['id'];
                						    
                						    $totalm=$totalm+1;
    									}
            						}
        						}
    						}   
						}
					}


}
//---------------------------------------//
$totalm1=0;
$amountclassm1;
$executive_id=$iii['executive_id'];
 $u=explode(",",$executive_id);
foreach($u as $uu =>$value)
	{
		$aa=$obj->fetchById($u[$uu],"agent","id");
	 	  $id=$aa['id'];

	$rsu=$obj->fetchDetailById(1,"user_register_goverment","pstatus");
					//print_r($rsu);
					//echo "</br>";
					if($rsu)
					{	
						while($row21=mysqli_fetch_assoc($rsu))
						{	$i++;
    						if($row21['pro_id']=='')
    						{}
    						else
    						{
    						   
    						    
        							 $pro = $row21['pro_id'];
        						$aa1=$obj->fetchById($pro,"pro_register","pro_id");
        				
        						 	$refferal_agent_id=$aa1['refferal_agent_id'];
        						if($refferal_agent_id=='')
        						{}
        						else
        						{
        						    
        					
            						if($id==$refferal_agent_id)	
            						{
            						     $payment_s=$row21['success_date'];
									$dd1=explode("-",$payment_s);
									 $yy2=$dd1['1'];
									$date=date("Y-m-d");
									$dd=explode("-",$date);
									 $yy1=$dd['1'];
    									if($yy2==$yy1)
    									{
            						     $row21['id'];
            						    
            						    $totalm1=$totalm1+1;
    									}
            						}
        						}
    						}   
						}
					}


}
//-----------------------------//
echo $totalm+$totalm1; 
   ?></span> <span class="slight"><i class="fa fa-play fa-rotate-270 text-warning"> </i></span></h2>
                                    <div class="small">This month Total user </div>
                                  <i class="fa fa-user" style="font-size: 50px; position: absolute;right: 30px; top: 16px;"></i>
                                  <!--  <div class="sparkline1 text-center"></div>-->
                                </div> <!-- /. statistic box -->
                            </div>
                            <div class="col-xs-4">
                                <!-- statistic box -->
                                <div class="statistic-box statistic-filled-2" style="    background: #3bd9d9;
    border-color: #3bd9d9;
    color: #fff;">
                                    <h2><span class="count-number"><?php
      $amo1=$obj->fetchByIdByStatus(0,"markting_price","class","type_user",1);
    						   $amountclassn1= $amo1['price'];
                                   $x= $totalm1*$amountclassn1;
                                   $y= $totalm* $amountclassm;
                                   echo $x+$y;
         
    ?></span> <span class="slight"><i class="fa fa-play fa-rotate-90 c-white"> </i> </span> </h2>
                                    <div class="small">This month Total Amount</div>
                                <i class="fa fa-inr" style="font-size: 50px; position: absolute;right: 30px; top: 16px;"></i>
                                    <!--<div class="sparkline2 text-center"></div>-->
                                </div>  <!-- /.statistic box -->
                            </div>
                                                    </div>
						<!----Last Month -->
						
						<div class="row">
						<div class="header-title">
                                <h1 style="text-align: center;"> Last Month Report</h1>
								</div>
                            <div class="col-xs-4"  >
                                <!-- statistic box -->
                                <div class="statistic-box statistic-filled-1" >
                                    <h2><span class="count-number"><?php  $tot48=0;
  

$totall=0;
$amountclassl;
$executive_id=$iii['executive_id'];
 $u=explode(",",$executive_id);
foreach($u as $uu =>$value)
	{
		$aa=$obj->fetchById($u[$uu],"agent","id");
	 	  $id=$aa['id'];

	$rsu=$obj->fetchDetailById(1,"user_register","pstatus");
					//print_r($rsu);
					//echo "</br>";
					if($rsu)
					{	
						while($row21=mysqli_fetch_assoc($rsu))
						{	$i++;
    						if($row21['pro_id']=='')
    						{}
    						else
    						{
    						    $class=$row21['class'];
    						    $amo=$obj->fetchByIdByStatus($class,"markting_price","class","type_user",1);
    						   $amountclassl= $amo['price'];
        							 $pro = $row21['pro_id'];
        						$aa1=$obj->fetchById($pro,"pro_register","pro_id");
        				
        						 	$refferal_agent_id=$aa1['refferal_agent_id'];
        						if($refferal_agent_id=='')
        						{}
        						else
        						{
        						    
        					
            						if($id==$refferal_agent_id)	
            						{
            						 $payment_success_date48=$row21['payment_success_date'];
                                	$month48=explode("-",$payment_success_date48);
									 $m48=$month48['1'];
								
								
							
									$date=date("Y-m-d");
									$lm48=explode("-",$date);
									 $lm49=$lm48['1'];
									 
									  $last48=$lm49-1;
									if($last48=='0')
									{
							
									$last49=12;
									}else
									{
									$last49=$last48;
									}
										if($m48==$last49)
										{
                						     $row21['id'];
                						    
                						    $totall=$totall+1;
    									}
            						}
        						}
    						}   
						}
					}


}
//-----------------------//

$totall1=0;
$amountclassm1;
$executive_id=$iii['executive_id'];
 $u=explode(",",$executive_id);
foreach($u as $uu =>$value)
	{
		$aa=$obj->fetchById($u[$uu],"agent","id");
	 	  $id=$aa['id'];

	$rsu=$obj->fetchDetailById(1,"user_register_goverment","pstatus");
					//print_r($rsu);
					//echo "</br>";
					if($rsu)
					{	
						while($row21=mysqli_fetch_assoc($rsu))
						{	$i++;
    						if($row21['pro_id']=='')
    						{}
    						else
    						{
    						   
    						    
        							 $pro = $row21['pro_id'];
        						$aa1=$obj->fetchById($pro,"pro_register","pro_id");
        				
        						 	$refferal_agent_id=$aa1['refferal_agent_id'];
        						if($refferal_agent_id=='')
        						{}
        						else
        						{
        						    
        					
            						if($id==$refferal_agent_id)	
            						{
            						     
									$payment_success_date48=$row21['success_date'];
                                	$month48=explode("-",$payment_success_date48);
									 $m48=$month48['1'];
								
								
							
									$date=date("Y-m-d");
									$lm48=explode("-",$date);
									 $lm49=$lm48['1'];
									 
									  $last48=$lm49-1;
									if($last48=='0')
									{
							
									$last49=12;
									}else
									{
									$last49=$last48;
									}
										if($m48==$last49)
										{
            						     $row21['id'];
            						    
            						    $totall1=$totall1+1;
    									}
            						}
        						}
    						}   
						}
					}


}

echo $totall+$totall1;
 ?>
			 </span> <span class="slight"><i class="fa fa-play fa-rotate-270 text-warning"> </i></span></h2>
                                    <div class="small">Last month Total user </div>
                                  <i class="fa fa-user" style="font-size: 50px; position: absolute;right: 30px; top: 16px;"></i>
                                  <!--  <div class="sparkline1 text-center"></div>-->
                                </div> <!-- /. statistic box -->
                            </div>
                            <div class="col-xs-4">
                                <!-- statistic box -->
                                <div class="statistic-box statistic-filled-2">
                                    <h2><span class="count-number"><?php 
  $amol1=$obj->fetchByIdByStatus(0,"markting_price","class","type_user",1);
    						   $amountclassl1= $amol1['price'];
                                   $p= $totall1*$amountclassl1;
                                   $q= $totall* $amountclassl;
                                   echo $p+$q;
				
                                            ?></span> <span class="slight"><i class="fa fa-play fa-rotate-90 c-white"> </i> </span> </h2>
                                    <div class="small">Last month Total Amount</div>
                                <i class="fa fa-inr" style="font-size: 50px; position: absolute;right: 30px; top: 16px;"></i>
                                    <!--<div class="sparkline2 text-center"></div>-->
                                </div>  <!-- /.statistic box -->
                            </div>
                            
                        </div>
						<!----Number Of Block Supervisor--->
						
						<div class="row">
						<div class="header-title">
                                <h1 style="text-align: center;"> Number of Executive Supervisor</h1>
								</div>
                            <div class="col-xs-4"  >
                                <!-- statistic box -->
                                <div class="statistic-box statistic-filled-1" style=" background-color: #352c2c;   border-color: #352c2c;color: #fff;">
                                    <h2><span class="count-number"><?php  

						  
						  $uu=0;
					 $executive_id=$iii['executive_id'];
					 $u4=explode(",",$executive_id);
			foreach($u4 as $uu4 =>$value4)
				{
							$uu=$uu+1;		}	
echo $uu; 	

										

   ?>
			 </span> <span class="slight"><i class="fa fa-play fa-rotate-270 text-warning"> </i></span></h2>
                                    <div class="small"> </div>
                                  <i class="fa fa-user" style="font-size: 50px; position: absolute;right: 30px; top: 16px;"></i>
                                  <!--  <div class="sparkline1 text-center"></div>-->
                                </div> <!-- /. statistic box -->
                            </div>
                            
                                <!-- statistic box -->
                                
                            
                        </div>
						
						
						
						
						
                            <!-- Chat -->
                        
                        </div> <!-- /.row -->
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
       <?php  include("footer.php"); ?>