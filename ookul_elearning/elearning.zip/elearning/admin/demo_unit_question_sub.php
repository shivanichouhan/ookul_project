<?php
include"../include/database.php";
$obj=new database();

$class_id=$_POST['class_id'];

$subject=$_POST['subject'];
$chapter=$_POST['chapter'];
$question=$_POST['question'];



$rs=$obj->demo_insert_unit_test($class_id,$subject,$chapter,$question);
if($rs)
{
//	$_SESSION['msg']=" Insert Success Full";
	//header("location:demo_unit_question.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_unit_question';
       </script>");
}
else
{
//	$_SESSION['msg']=" Not Insert";
	//header("location:demo_unit_question.php");
		echo ("<script LANGUAGE='JavaScript'>
          window.alert('');
          window.location.href='demo_unit_question';
       </script>");
}
?>