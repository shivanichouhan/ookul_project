<?php
session_start();
class config
{
	const host="localhost";
	const username="educatio_sveltose";
	const password="L&}V_)5Fs3!0";
	const database="educatio_elearning";
}
date_default_timezone_set("Asia/Kolkata");
?>